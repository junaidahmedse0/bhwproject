using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class CountryRepository : ICountryRepository
{
async public Task<List<CountryDTO>> GetAllCountryAsync()
{
var result = new List<CountryDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Country>()
.Select(_ => new CountryDTO()
 {
CountryId = _.CountryId,
Title = _.Title,
ShortCode = _.ShortCode,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.CountryId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateCountryAsync(CountryDTO countryDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
Country newRecord = new Country(uow);
newRecord.CountryId = countryDTO.CountryId;
newRecord.Title = countryDTO.Title;
newRecord.ShortCode = countryDTO.ShortCode;
newRecord.DateCreated = countryDTO.DateCreated;
newRecord.DateUpdated = countryDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.CountryId;
}}
async public Task UpdateCountryAsync(CountryDTO CountryDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Country>().Where(_ => _.CountryId == CountryDTO.CountryId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.CountryId = CountryDTO.CountryId;
recordToUpdate.Title = CountryDTO.Title;
recordToUpdate.ShortCode = CountryDTO.ShortCode;
recordToUpdate.DateCreated = CountryDTO.DateCreated;
recordToUpdate.DateUpdated = CountryDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteCountryAsync(CountryDTO countryDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Country>().Where(_ => _.CountryId == countryDTO.CountryId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
