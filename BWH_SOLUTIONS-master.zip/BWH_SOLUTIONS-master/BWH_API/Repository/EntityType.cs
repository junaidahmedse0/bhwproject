using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class EntityTypeRepository : IEntityTypeRepository
{
async public Task<List<EntityTypeDTO>> GetAllEntityTypeAsync()
{
var result = new List<EntityTypeDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<EntityType>()
.Select(_ => new EntityTypeDTO()
 {
EntityTypeId = _.EntityTypeId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.EntityTypeId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateEntityTypeAsync(EntityTypeDTO entityTypeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
EntityType newRecord = new EntityType(uow);
newRecord.EntityTypeId = entityTypeDTO.EntityTypeId;
newRecord.Title = entityTypeDTO.Title;
newRecord.DateCreated = entityTypeDTO.DateCreated;
newRecord.DateUpdated = entityTypeDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.EntityTypeId;
}}
async public Task UpdateEntityTypeAsync(EntityTypeDTO EntityTypeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<EntityType>().Where(_ => _.EntityTypeId == EntityTypeDTO.EntityTypeId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.EntityTypeId = EntityTypeDTO.EntityTypeId;
recordToUpdate.Title = EntityTypeDTO.Title;
recordToUpdate.DateCreated = EntityTypeDTO.DateCreated;
recordToUpdate.DateUpdated = EntityTypeDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteEntityTypeAsync(EntityTypeDTO entityTypeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<EntityType>().Where(_ => _.EntityTypeId == entityTypeDTO.EntityTypeId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
