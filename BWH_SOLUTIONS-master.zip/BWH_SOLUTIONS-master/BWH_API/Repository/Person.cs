using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class PersonRepository : IPersonRepository
{
async public Task<List<PersonDTO>> GetAllPersonAsync()
{
var result = new List<PersonDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Person>()
.Select(_ => new PersonDTO()
 {
PersonId = _.PersonId,
ExpertiseAreaId = _.ExpertiseAreaId,
AdditionalExpertiseAreaId = _.AdditionalExpertiseAreaId,
Name = _.Name,
Mail = _.Mail,
Info = _.Info,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.PersonId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreatePersonAsync(PersonDTO personDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
Person newRecord = new Person(uow);
newRecord.PersonId = personDTO.PersonId;
newRecord.ExpertiseAreaId = personDTO.ExpertiseAreaId;
newRecord.AdditionalExpertiseAreaId = personDTO.AdditionalExpertiseAreaId;
newRecord.Name = personDTO.Name;
newRecord.Mail = personDTO.Mail;
newRecord.Info = personDTO.Info;
newRecord.DateCreated = personDTO.DateCreated;
newRecord.DateUpdated = personDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.PersonId;
}}
async public Task UpdatePersonAsync(PersonDTO PersonDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Person>().Where(_ => _.PersonId == PersonDTO.PersonId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.PersonId = PersonDTO.PersonId;
recordToUpdate.ExpertiseAreaId = PersonDTO.ExpertiseAreaId;
recordToUpdate.AdditionalExpertiseAreaId = PersonDTO.AdditionalExpertiseAreaId;
recordToUpdate.Name = PersonDTO.Name;
recordToUpdate.Mail = PersonDTO.Mail;
recordToUpdate.Info = PersonDTO.Info;
recordToUpdate.DateCreated = PersonDTO.DateCreated;
recordToUpdate.DateUpdated = PersonDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeletePersonAsync(PersonDTO personDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Person>().Where(_ => _.PersonId == personDTO.PersonId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
