using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class AmazonFeeTrackingRepository : IAmazonFeeTrackingRepository
{
async public Task<List<AmazonFeeTrackingDTO>> GetAllAmazonFeeTrackingAsync()
{
var result = new List<AmazonFeeTrackingDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<AmazonFeeTracking>()
.Select(_ => new AmazonFeeTrackingDTO()
 {
Id = _.Id,
Tag = _.Tag,
Clicks = _.Clicks,
ProductOrdered = _.ProductOrdered,
ProductShipped = _.ProductShipped,
ProductOrderedAmount = _.ProductOrderedAmount,
Earnings = _.Earnings
}).OrderBy(_ => _.Id).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonFeeTrackingDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
AmazonFeeTracking newRecord = new AmazonFeeTracking(uow);
newRecord.Id = amazonFeeTrackingDTO.Id;
newRecord.Tag = amazonFeeTrackingDTO.Tag;
newRecord.Clicks = amazonFeeTrackingDTO.Clicks;
newRecord.ProductOrdered = amazonFeeTrackingDTO.ProductOrdered;
newRecord.ProductShipped = amazonFeeTrackingDTO.ProductShipped;
newRecord.ProductOrderedAmount = amazonFeeTrackingDTO.ProductOrderedAmount;
newRecord.Earnings = amazonFeeTrackingDTO.Earnings;
await uow.CommitChangesAsync();
return newRecord.Id;
}}
async public Task UpdateAmazonFeeTrackingAsync(AmazonFeeTrackingDTO AmazonFeeTrackingDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<AmazonFeeTracking>().Where(_ => _.Id == AmazonFeeTrackingDTO.Id).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.Id = AmazonFeeTrackingDTO.Id;
recordToUpdate.Tag = AmazonFeeTrackingDTO.Tag;
recordToUpdate.Clicks = AmazonFeeTrackingDTO.Clicks;
recordToUpdate.ProductOrdered = AmazonFeeTrackingDTO.ProductOrdered;
recordToUpdate.ProductShipped = AmazonFeeTrackingDTO.ProductShipped;
recordToUpdate.ProductOrderedAmount = AmazonFeeTrackingDTO.ProductOrderedAmount;
recordToUpdate.Earnings = AmazonFeeTrackingDTO.Earnings;
await uow.CommitChangesAsync();
}}}
async public Task DeleteAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonFeeTrackingDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<AmazonFeeTracking>().Where(_ => _.Id == amazonFeeTrackingDTO.Id).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
