using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class FamilyRepository : IFamilyRepository
{
async public Task<List<FamilyDTO>> GetAllFamilyAsync()
{
var result = new List<FamilyDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Family>()
.Select(_ => new FamilyDTO()
 {
FamilyId = _.FamilyId,
Title = _.Title,
DateCreated = _.DateCreated,
UpdatedDate = _.UpdatedDate
}).OrderBy(_ => _.FamilyId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateFamilyAsync(FamilyDTO familyDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
Family newRecord = new Family(uow);
newRecord.FamilyId = familyDTO.FamilyId;
newRecord.Title = familyDTO.Title;
newRecord.DateCreated = familyDTO.DateCreated;
newRecord.UpdatedDate = familyDTO.UpdatedDate;
await uow.CommitChangesAsync();
return newRecord.FamilyId;
}}
async public Task UpdateFamilyAsync(FamilyDTO FamilyDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Family>().Where(_ => _.FamilyId == FamilyDTO.FamilyId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.FamilyId = FamilyDTO.FamilyId;
recordToUpdate.Title = FamilyDTO.Title;
recordToUpdate.DateCreated = FamilyDTO.DateCreated;
recordToUpdate.UpdatedDate = FamilyDTO.UpdatedDate;
await uow.CommitChangesAsync();
}}}
async public Task DeleteFamilyAsync(FamilyDTO familyDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Family>().Where(_ => _.FamilyId == familyDTO.FamilyId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
