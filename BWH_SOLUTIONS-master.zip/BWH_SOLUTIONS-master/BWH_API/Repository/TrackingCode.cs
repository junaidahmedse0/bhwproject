using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class TrackingCodeRepository : ITrackingCodeRepository
{
async public Task<List<TrackingCodeDTO>> GetAllTrackingCodeAsync()
{
var result = new List<TrackingCodeDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<TrackingCode>()
.Select(_ => new TrackingCodeDTO()
 {
TrackingCodeId = _.TrackingCodeId,
Title = _.Title,
Tag = _.Tag,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.TrackingCodeId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateTrackingCodeAsync(TrackingCodeDTO trackingCodeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
TrackingCode newRecord = new TrackingCode(uow);
newRecord.TrackingCodeId = trackingCodeDTO.TrackingCodeId;
newRecord.Title = trackingCodeDTO.Title;
newRecord.Tag = trackingCodeDTO.Tag;
newRecord.DateCreated = trackingCodeDTO.DateCreated;
newRecord.DateUpdated = trackingCodeDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.TrackingCodeId;
}}
async public Task UpdateTrackingCodeAsync(TrackingCodeDTO TrackingCodeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<TrackingCode>().Where(_ => _.TrackingCodeId == TrackingCodeDTO.TrackingCodeId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.TrackingCodeId = TrackingCodeDTO.TrackingCodeId;
recordToUpdate.Title = TrackingCodeDTO.Title;
recordToUpdate.Tag = TrackingCodeDTO.Tag;
recordToUpdate.DateCreated = TrackingCodeDTO.DateCreated;
recordToUpdate.DateUpdated = TrackingCodeDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteTrackingCodeAsync(TrackingCodeDTO trackingCodeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<TrackingCode>().Where(_ => _.TrackingCodeId == trackingCodeDTO.TrackingCodeId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
