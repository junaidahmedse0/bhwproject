using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class RegistrarRepository : IRegistrarRepository
{
async public Task<List<RegistrarDTO>> GetAllRegistrarAsync()
{
var result = new List<RegistrarDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Registrar>()
.Select(_ => new RegistrarDTO()
 {
RegistrarId = _.RegistrarId,
Name = _.Name,
Url = _.Url,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.RegistrarId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateRegistrarAsync(RegistrarDTO registrarDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
Registrar newRecord = new Registrar(uow);
newRecord.RegistrarId = registrarDTO.RegistrarId;
newRecord.Name = registrarDTO.Name;
newRecord.Url = registrarDTO.Url;
newRecord.DateCreated = registrarDTO.DateCreated;
newRecord.DateUpdated = registrarDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.RegistrarId;
}}
async public Task UpdateRegistrarAsync(RegistrarDTO RegistrarDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Registrar>().Where(_ => _.RegistrarId == RegistrarDTO.RegistrarId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.RegistrarId = RegistrarDTO.RegistrarId;
recordToUpdate.Name = RegistrarDTO.Name;
recordToUpdate.Url = RegistrarDTO.Url;
recordToUpdate.DateCreated = RegistrarDTO.DateCreated;
recordToUpdate.DateUpdated = RegistrarDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteRegistrarAsync(RegistrarDTO registrarDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Registrar>().Where(_ => _.RegistrarId == registrarDTO.RegistrarId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
