using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class ThemeRepository : IThemeRepository
{
async public Task<List<ThemeDTO>> GetAllThemeAsync()
{
var result = new List<ThemeDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Theme>()
.Select(_ => new ThemeDTO()
 {
ThemeId = _.ThemeId,
TechnicalStatusId = _.TechnicalStatusId,
CreatorId = _.CreatorId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.ThemeId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateThemeAsync(ThemeDTO themeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
Theme newRecord = new Theme(uow);
newRecord.ThemeId = themeDTO.ThemeId;
newRecord.TechnicalStatusId = themeDTO.TechnicalStatusId;
newRecord.CreatorId = themeDTO.CreatorId;
newRecord.Title = themeDTO.Title;
newRecord.DateCreated = themeDTO.DateCreated;
newRecord.DateUpdated = themeDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.ThemeId;
}}
async public Task UpdateThemeAsync(ThemeDTO ThemeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Theme>().Where(_ => _.ThemeId == ThemeDTO.ThemeId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.ThemeId = ThemeDTO.ThemeId;
recordToUpdate.TechnicalStatusId = ThemeDTO.TechnicalStatusId;
recordToUpdate.CreatorId = ThemeDTO.CreatorId;
recordToUpdate.Title = ThemeDTO.Title;
recordToUpdate.DateCreated = ThemeDTO.DateCreated;
recordToUpdate.DateUpdated = ThemeDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteThemeAsync(ThemeDTO themeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Theme>().Where(_ => _.ThemeId == themeDTO.ThemeId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
