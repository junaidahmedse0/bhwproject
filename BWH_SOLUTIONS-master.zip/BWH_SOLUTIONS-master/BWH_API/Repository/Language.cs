using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class LanguageRepository : ILanguageRepository
{
async public Task<List<LanguageDTO>> GetAllLanguageAsync()
{
var result = new List<LanguageDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Language>()
.Select(_ => new LanguageDTO()
 {
LanguageId = _.LanguageId,
Title = _.Title,
Code = _.Code,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.LanguageId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateLanguageAsync(LanguageDTO languageDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
Language newRecord = new Language(uow);
newRecord.LanguageId = languageDTO.LanguageId;
newRecord.Title = languageDTO.Title;
newRecord.Code = languageDTO.Code;
newRecord.DateCreated = languageDTO.DateCreated;
newRecord.DateUpdated = languageDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.LanguageId;
}}
async public Task UpdateLanguageAsync(LanguageDTO LanguageDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Language>().Where(_ => _.LanguageId == LanguageDTO.LanguageId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.LanguageId = LanguageDTO.LanguageId;
recordToUpdate.Title = LanguageDTO.Title;
recordToUpdate.Code = LanguageDTO.Code;
recordToUpdate.DateCreated = LanguageDTO.DateCreated;
recordToUpdate.DateUpdated = LanguageDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteLanguageAsync(LanguageDTO languageDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Language>().Where(_ => _.LanguageId == languageDTO.LanguageId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
