using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class DomainNameRepository : IDomainNameRepository
{
async public Task<List<DomainNameDTO>> GetAllDomainNameAsync()
{
var result = new List<DomainNameDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<DomainName>()
.Select(_ => new DomainNameDTO()
 {
DomainNameId = _.DomainNameId,
RegistrarId = _.RegistrarId,
Title = _.Title,
SubscriptionStartingDate = _.SubscriptionStartingDate,
NextRenewalDate = _.NextRenewalDate,
Price = _.Price,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated,
TechnicalStatusId = _.TechnicalStatusId
}).OrderBy(_ => _.DomainNameId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateDomainNameAsync(DomainNameDTO domainNameDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
DomainName newRecord = new DomainName(uow);
newRecord.DomainNameId = domainNameDTO.DomainNameId;
newRecord.RegistrarId = domainNameDTO.RegistrarId;
newRecord.Title = domainNameDTO.Title;
newRecord.SubscriptionStartingDate = domainNameDTO.SubscriptionStartingDate;
newRecord.NextRenewalDate = domainNameDTO.NextRenewalDate;
newRecord.Price = domainNameDTO.Price;
newRecord.DateCreated = domainNameDTO.DateCreated;
newRecord.DateUpdated = domainNameDTO.DateUpdated;
newRecord.TechnicalStatusId = domainNameDTO.TechnicalStatusId;
await uow.CommitChangesAsync();
return newRecord.DomainNameId;
}}
async public Task UpdateDomainNameAsync(DomainNameDTO DomainNameDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<DomainName>().Where(_ => _.DomainNameId == DomainNameDTO.DomainNameId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.DomainNameId = DomainNameDTO.DomainNameId;
recordToUpdate.RegistrarId = DomainNameDTO.RegistrarId;
recordToUpdate.Title = DomainNameDTO.Title;
recordToUpdate.SubscriptionStartingDate = DomainNameDTO.SubscriptionStartingDate;
recordToUpdate.NextRenewalDate = DomainNameDTO.NextRenewalDate;
recordToUpdate.Price = DomainNameDTO.Price;
recordToUpdate.DateCreated = DomainNameDTO.DateCreated;
recordToUpdate.DateUpdated = DomainNameDTO.DateUpdated;
recordToUpdate.TechnicalStatusId = DomainNameDTO.TechnicalStatusId;
await uow.CommitChangesAsync();
}}}
async public Task DeleteDomainNameAsync(DomainNameDTO domainNameDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<DomainName>().Where(_ => _.DomainNameId == domainNameDTO.DomainNameId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
