using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class ProjectTrackingCodeRepository : IProjectTrackingCodeRepository
{
async public Task<List<ProjectTrackingCodeDTO>> GetAllProjectTrackingCodeAsync()
{
var result = new List<ProjectTrackingCodeDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<ProjectTrackingCode>()
.Select(_ => new ProjectTrackingCodeDTO()
 {
ProjectTrackingCodeId = _.ProjectTrackingCodeId,
TrackingCodeId = _.TrackingCodeId,
ProjectId = _.ProjectId,
Code = _.Code,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.ProjectTrackingCodeId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateProjectTrackingCodeAsync(ProjectTrackingCodeDTO projectTrackingCodeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
ProjectTrackingCode newRecord = new ProjectTrackingCode(uow);
newRecord.ProjectTrackingCodeId = projectTrackingCodeDTO.ProjectTrackingCodeId;
newRecord.TrackingCodeId = projectTrackingCodeDTO.TrackingCodeId;
newRecord.ProjectId = projectTrackingCodeDTO.ProjectId;
newRecord.Code = projectTrackingCodeDTO.Code;
newRecord.DateCreated = projectTrackingCodeDTO.DateCreated;
newRecord.DateUpdated = projectTrackingCodeDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.ProjectTrackingCodeId;
}}
async public Task UpdateProjectTrackingCodeAsync(ProjectTrackingCodeDTO ProjectTrackingCodeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<ProjectTrackingCode>().Where(_ => _.ProjectTrackingCodeId == ProjectTrackingCodeDTO.ProjectTrackingCodeId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.ProjectTrackingCodeId = ProjectTrackingCodeDTO.ProjectTrackingCodeId;
recordToUpdate.TrackingCodeId = ProjectTrackingCodeDTO.TrackingCodeId;
recordToUpdate.ProjectId = ProjectTrackingCodeDTO.ProjectId;
recordToUpdate.Code = ProjectTrackingCodeDTO.Code;
recordToUpdate.DateCreated = ProjectTrackingCodeDTO.DateCreated;
recordToUpdate.DateUpdated = ProjectTrackingCodeDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteProjectTrackingCodeAsync(ProjectTrackingCodeDTO projectTrackingCodeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<ProjectTrackingCode>().Where(_ => _.ProjectTrackingCodeId == projectTrackingCodeDTO.ProjectTrackingCodeId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
