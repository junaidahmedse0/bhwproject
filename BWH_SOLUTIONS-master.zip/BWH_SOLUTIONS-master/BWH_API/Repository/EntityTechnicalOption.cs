using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class EntityTechnicalOptionRepository : IEntityTechnicalOptionRepository
{
async public Task<List<EntityTechnicalOptionDTO>> GetAllEntityTechnicalOptionAsync()
{
var result = new List<EntityTechnicalOptionDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<EntityTechnicalOption>()
.Select(_ => new EntityTechnicalOptionDTO()
 {
EntityTechnicalOptionId = _.EntityTechnicalOptionId,
EntityId = _.EntityId,
TechnicalOptionId = _.TechnicalOptionId,
TechnicalOptionValue = _.TechnicalOptionValue,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.EntityTechnicalOptionId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entityTechnicalOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
EntityTechnicalOption newRecord = new EntityTechnicalOption(uow);
newRecord.EntityTechnicalOptionId = entityTechnicalOptionDTO.EntityTechnicalOptionId;
newRecord.EntityId = entityTechnicalOptionDTO.EntityId;
newRecord.TechnicalOptionId = entityTechnicalOptionDTO.TechnicalOptionId;
newRecord.TechnicalOptionValue = entityTechnicalOptionDTO.TechnicalOptionValue;
newRecord.DateCreated = entityTechnicalOptionDTO.DateCreated;
newRecord.DateUpdated = entityTechnicalOptionDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.EntityTechnicalOptionId;
}}
async public Task UpdateEntityTechnicalOptionAsync(EntityTechnicalOptionDTO EntityTechnicalOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<EntityTechnicalOption>().Where(_ => _.EntityTechnicalOptionId == EntityTechnicalOptionDTO.EntityTechnicalOptionId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.EntityTechnicalOptionId = EntityTechnicalOptionDTO.EntityTechnicalOptionId;
recordToUpdate.EntityId = EntityTechnicalOptionDTO.EntityId;
recordToUpdate.TechnicalOptionId = EntityTechnicalOptionDTO.TechnicalOptionId;
recordToUpdate.TechnicalOptionValue = EntityTechnicalOptionDTO.TechnicalOptionValue;
recordToUpdate.DateCreated = EntityTechnicalOptionDTO.DateCreated;
recordToUpdate.DateUpdated = EntityTechnicalOptionDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entityTechnicalOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<EntityTechnicalOption>().Where(_ => _.EntityTechnicalOptionId == entityTechnicalOptionDTO.EntityTechnicalOptionId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
