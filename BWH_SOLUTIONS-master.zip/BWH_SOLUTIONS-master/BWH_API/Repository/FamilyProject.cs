using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class FamilyProjectRepository : IFamilyProjectRepository
{
async public Task<List<FamilyProjectDTO>> GetAllFamilyProjectAsync()
{
var result = new List<FamilyProjectDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<FamilyProject>()
.Select(_ => new FamilyProjectDTO()
 {
FamilyProjectId = _.FamilyProjectId,
FamilyId = _.FamilyId,
ProjectId = _.ProjectId,
Title = _.Title,
DateCreated = _.DateCreated,
UpdatedDate = _.UpdatedDate
}).OrderBy(_ => _.FamilyProjectId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateFamilyProjectAsync(FamilyProjectDTO familyProjectDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
FamilyProject newRecord = new FamilyProject(uow);
newRecord.FamilyProjectId = familyProjectDTO.FamilyProjectId;
newRecord.FamilyId = familyProjectDTO.FamilyId;
newRecord.ProjectId = familyProjectDTO.ProjectId;
newRecord.Title = familyProjectDTO.Title;
newRecord.DateCreated = familyProjectDTO.DateCreated;
newRecord.UpdatedDate = familyProjectDTO.UpdatedDate;
await uow.CommitChangesAsync();
return newRecord.FamilyProjectId;
}}
async public Task UpdateFamilyProjectAsync(FamilyProjectDTO FamilyProjectDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<FamilyProject>().Where(_ => _.FamilyProjectId == FamilyProjectDTO.FamilyProjectId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.FamilyProjectId = FamilyProjectDTO.FamilyProjectId;
recordToUpdate.FamilyId = FamilyProjectDTO.FamilyId;
recordToUpdate.ProjectId = FamilyProjectDTO.ProjectId;
recordToUpdate.Title = FamilyProjectDTO.Title;
recordToUpdate.DateCreated = FamilyProjectDTO.DateCreated;
recordToUpdate.UpdatedDate = FamilyProjectDTO.UpdatedDate;
await uow.CommitChangesAsync();
}}}
async public Task DeleteFamilyProjectAsync(FamilyProjectDTO familyProjectDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<FamilyProject>().Where(_ => _.FamilyProjectId == familyProjectDTO.FamilyProjectId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
