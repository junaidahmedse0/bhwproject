using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class AmazonFeeOrdersRepository : IAmazonFeeOrdersRepository
{
async public Task<List<AmazonFeeOrdersDTO>> GetAllAmazonFeeOrdersAsync()
{
var result = new List<AmazonFeeOrdersDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<AmazonFeeOrders>()
.Select(_ => new AmazonFeeOrdersDTO()
 {
Id = _.Id,
Category = _.Category,
Product = _.Product,
AmazonStandardIdentificationNumber = _.AmazonStandardIdentificationNumber,
OperationDate = _.OperationDate,
Quantity = _.Quantity,
Price = _.Price,
LinkType = _.LinkType,
Tag = _.Tag,
LinkProductOrder = _.LinkProductOrder,
Device = _.Device
}).OrderBy(_ => _.Id).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonFeeOrdersDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
AmazonFeeOrders newRecord = new AmazonFeeOrders(uow);
newRecord.Id = amazonFeeOrdersDTO.Id;
newRecord.Category = amazonFeeOrdersDTO.Category;
newRecord.Product = amazonFeeOrdersDTO.Product;
newRecord.AmazonStandardIdentificationNumber = amazonFeeOrdersDTO.AmazonStandardIdentificationNumber;
newRecord.OperationDate = amazonFeeOrdersDTO.OperationDate;
newRecord.Quantity = amazonFeeOrdersDTO.Quantity;
newRecord.Price = amazonFeeOrdersDTO.Price;
newRecord.LinkType = amazonFeeOrdersDTO.LinkType;
newRecord.Tag = amazonFeeOrdersDTO.Tag;
newRecord.LinkProductOrder = amazonFeeOrdersDTO.LinkProductOrder;
newRecord.Device = amazonFeeOrdersDTO.Device;
await uow.CommitChangesAsync();
return newRecord.Id;
}}
async public Task UpdateAmazonFeeOrdersAsync(AmazonFeeOrdersDTO AmazonFeeOrdersDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<AmazonFeeOrders>().Where(_ => _.Id == AmazonFeeOrdersDTO.Id).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.Id = AmazonFeeOrdersDTO.Id;
recordToUpdate.Category = AmazonFeeOrdersDTO.Category;
recordToUpdate.Product = AmazonFeeOrdersDTO.Product;
recordToUpdate.AmazonStandardIdentificationNumber = AmazonFeeOrdersDTO.AmazonStandardIdentificationNumber;
recordToUpdate.OperationDate = AmazonFeeOrdersDTO.OperationDate;
recordToUpdate.Quantity = AmazonFeeOrdersDTO.Quantity;
recordToUpdate.Price = AmazonFeeOrdersDTO.Price;
recordToUpdate.LinkType = AmazonFeeOrdersDTO.LinkType;
recordToUpdate.Tag = AmazonFeeOrdersDTO.Tag;
recordToUpdate.LinkProductOrder = AmazonFeeOrdersDTO.LinkProductOrder;
recordToUpdate.Device = AmazonFeeOrdersDTO.Device;
await uow.CommitChangesAsync();
}}}
async public Task DeleteAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonFeeOrdersDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<AmazonFeeOrders>().Where(_ => _.Id == amazonFeeOrdersDTO.Id).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
