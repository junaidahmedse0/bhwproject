using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
    public class MainRequestRepository : IMainRequestRepository
    {
        async public Task<List<MainRequestDTO>> GetAllMainRequestAsync()
        {
            var result = new List<MainRequestDTO>();
            using (var uow = ConnectionHelper.CreateUnitOfWork())
            {
                result = await uow.Query<MainRequest>()
                .Select(_ => new MainRequestDTO()
                {
                    MainRequestId = _.MainRequestId,
                    MainRequestParentId = _.MainRequestParentId,
                    LanguageId = _.LanguageId,
                    MainRequest = _.MMainRequest,
                    LexicalField1 = _.LexicalField1,
                    LexicalField2 = _.LexicalField2,
                    LexicalField3 = _.LexicalField3,
                    LexicalField4 = _.LexicalField4,
                    LexicalField5 = _.LexicalField5,
                    LexicalField6 = _.LexicalField6,
                    DateCreated = _.DateCreated,
                    DateUpdated = _.DateUpdated
                }).OrderBy(_ => _.MainRequestId).Distinct().ToListAsync();
            }
            return result;
        }
        async public Task<int> CreateMainRequestAsync(MainRequestDTO mainRequestDTO)
        {
            using (var uow = ConnectionHelper.CreateUnitOfWork())
            {
                MainRequest newRecord = new MainRequest(uow);
                newRecord.MainRequestId = mainRequestDTO.MainRequestId;
                newRecord.MainRequestParentId = mainRequestDTO.MainRequestParentId;
                newRecord.LanguageId = mainRequestDTO.LanguageId;
                newRecord.MMainRequest = mainRequestDTO.MainRequest;
                newRecord.LexicalField1 = mainRequestDTO.LexicalField1;
                newRecord.LexicalField2 = mainRequestDTO.LexicalField2;
                newRecord.LexicalField3 = mainRequestDTO.LexicalField3;
                newRecord.LexicalField4 = mainRequestDTO.LexicalField4;
                newRecord.LexicalField5 = mainRequestDTO.LexicalField5;
                newRecord.LexicalField6 = mainRequestDTO.LexicalField6;
                newRecord.DateCreated = mainRequestDTO.DateCreated;
                newRecord.DateUpdated = mainRequestDTO.DateUpdated;
                await uow.CommitChangesAsync();
                return newRecord.MainRequestId;
            }
        }
        async public Task UpdateMainRequestAsync(MainRequestDTO MainRequestDTO)
        {
            using (var uow = ConnectionHelper.CreateUnitOfWork())
            {
                var recordToUpdate = uow.Query<MainRequest>().Where(_ => _.MainRequestId == MainRequestDTO.MainRequestId).FirstOrDefault();
                if (recordToUpdate != null)
                {
                    recordToUpdate.MainRequestId = MainRequestDTO.MainRequestId;
                    recordToUpdate.MainRequestParentId = MainRequestDTO.MainRequestParentId;
                    recordToUpdate.LanguageId = MainRequestDTO.LanguageId;
                    recordToUpdate.MMainRequest = MainRequestDTO.MainRequest;
                    recordToUpdate.LexicalField1 = MainRequestDTO.LexicalField1;
                    recordToUpdate.LexicalField2 = MainRequestDTO.LexicalField2;
                    recordToUpdate.LexicalField3 = MainRequestDTO.LexicalField3;
                    recordToUpdate.LexicalField4 = MainRequestDTO.LexicalField4;
                    recordToUpdate.LexicalField5 = MainRequestDTO.LexicalField5;
                    recordToUpdate.LexicalField6 = MainRequestDTO.LexicalField6;
                    recordToUpdate.DateCreated = MainRequestDTO.DateCreated;
                    recordToUpdate.DateUpdated = MainRequestDTO.DateUpdated;
                    await uow.CommitChangesAsync();
                }
            }
        }
        async public Task DeleteMainRequestAsync(MainRequestDTO mainRequestDTO)
        {
            using (var uow = ConnectionHelper.CreateUnitOfWork())
            {
                var deleteToUpdate = uow.Query<MainRequest>().Where(_ => _.MainRequestId == mainRequestDTO.MainRequestId).FirstOrDefault();
                if (deleteToUpdate != null)
                {
                    deleteToUpdate.Delete();
                    await uow.CommitChangesAsync();
                }
            }
        }
    }
}
