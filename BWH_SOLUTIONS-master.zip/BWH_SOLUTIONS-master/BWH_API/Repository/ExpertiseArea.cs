using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class ExpertiseAreaRepository : IExpertiseAreaRepository
{
async public Task<List<ExpertiseAreaDTO>> GetAllExpertiseAreaAsync()
{
var result = new List<ExpertiseAreaDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<ExpertiseArea>()
.Select(_ => new ExpertiseAreaDTO()
 {
ExpertiseAreaId = _.ExpertiseAreaId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.ExpertiseAreaId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateExpertiseAreaAsync(ExpertiseAreaDTO expertiseAreaDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
ExpertiseArea newRecord = new ExpertiseArea(uow);
newRecord.ExpertiseAreaId = expertiseAreaDTO.ExpertiseAreaId;
newRecord.Title = expertiseAreaDTO.Title;
newRecord.DateCreated = expertiseAreaDTO.DateCreated;
newRecord.DateUpdated = expertiseAreaDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.ExpertiseAreaId;
}}
async public Task UpdateExpertiseAreaAsync(ExpertiseAreaDTO ExpertiseAreaDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<ExpertiseArea>().Where(_ => _.ExpertiseAreaId == ExpertiseAreaDTO.ExpertiseAreaId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.ExpertiseAreaId = ExpertiseAreaDTO.ExpertiseAreaId;
recordToUpdate.Title = ExpertiseAreaDTO.Title;
recordToUpdate.DateCreated = ExpertiseAreaDTO.DateCreated;
recordToUpdate.DateUpdated = ExpertiseAreaDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteExpertiseAreaAsync(ExpertiseAreaDTO expertiseAreaDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<ExpertiseArea>().Where(_ => _.ExpertiseAreaId == expertiseAreaDTO.ExpertiseAreaId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
