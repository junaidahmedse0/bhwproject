using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class AmazonFeeDailyTrendsRepository : IAmazonFeeDailyTrendsRepository
{
async public Task<List<AmazonFeeDailyTrendsDTO>> GetAllAmazonFeeDailyTrendsAsync()
{
var result = new List<AmazonFeeDailyTrendsDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<AmazonFeeDailyTrends>()
.Select(_ => new AmazonFeeDailyTrendsDTO()
 {
Id = _.Id,
OperationDate = _.OperationDate,
Clicks = _.Clicks,
ProductOrdered = _.ProductOrdered,
ProductShipped = _.ProductShipped,
Conversion = _.Conversion
}).OrderBy(_ => _.Id).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonFeeDailyTrendsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
AmazonFeeDailyTrends newRecord = new AmazonFeeDailyTrends(uow);
newRecord.Id = amazonFeeDailyTrendsDTO.Id;
newRecord.OperationDate = amazonFeeDailyTrendsDTO.OperationDate;
newRecord.Clicks = amazonFeeDailyTrendsDTO.Clicks;
newRecord.ProductOrdered = amazonFeeDailyTrendsDTO.ProductOrdered;
newRecord.ProductShipped = amazonFeeDailyTrendsDTO.ProductShipped;
newRecord.Conversion = amazonFeeDailyTrendsDTO.Conversion;
await uow.CommitChangesAsync();
return newRecord.Id;
}}
async public Task UpdateAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO AmazonFeeDailyTrendsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<AmazonFeeDailyTrends>().Where(_ => _.Id == AmazonFeeDailyTrendsDTO.Id).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.Id = AmazonFeeDailyTrendsDTO.Id;
recordToUpdate.OperationDate = AmazonFeeDailyTrendsDTO.OperationDate;
recordToUpdate.Clicks = AmazonFeeDailyTrendsDTO.Clicks;
recordToUpdate.ProductOrdered = AmazonFeeDailyTrendsDTO.ProductOrdered;
recordToUpdate.ProductShipped = AmazonFeeDailyTrendsDTO.ProductShipped;
recordToUpdate.Conversion = AmazonFeeDailyTrendsDTO.Conversion;
await uow.CommitChangesAsync();
}}}
async public Task DeleteAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonFeeDailyTrendsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<AmazonFeeDailyTrends>().Where(_ => _.Id == amazonFeeDailyTrendsDTO.Id).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
