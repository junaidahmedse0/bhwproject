using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class BusinessSectorRepository : IBusinessSectorRepository
{
async public Task<List<BusinessSectorDTO>> GetAllBusinessSectorAsync()
{
var result = new List<BusinessSectorDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<BusinessSector>()
.Select(_ => new BusinessSectorDTO()
 {
BusinessSectorId = _.BusinessSectorId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.BusinessSectorId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateBusinessSectorAsync(BusinessSectorDTO businessSectorDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
BusinessSector newRecord = new BusinessSector(uow);
newRecord.BusinessSectorId = businessSectorDTO.BusinessSectorId;
newRecord.Title = businessSectorDTO.Title;
newRecord.DateCreated = businessSectorDTO.DateCreated;
newRecord.DateUpdated = businessSectorDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.BusinessSectorId;
}}
async public Task UpdateBusinessSectorAsync(BusinessSectorDTO BusinessSectorDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<BusinessSector>().Where(_ => _.BusinessSectorId == BusinessSectorDTO.BusinessSectorId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.BusinessSectorId = BusinessSectorDTO.BusinessSectorId;
recordToUpdate.Title = BusinessSectorDTO.Title;
recordToUpdate.DateCreated = BusinessSectorDTO.DateCreated;
recordToUpdate.DateUpdated = BusinessSectorDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteBusinessSectorAsync(BusinessSectorDTO businessSectorDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<BusinessSector>().Where(_ => _.BusinessSectorId == businessSectorDTO.BusinessSectorId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
