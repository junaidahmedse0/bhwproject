using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class AmazonFeeLinkTypeRepository : IAmazonFeeLinkTypeRepository
{
async public Task<List<AmazonFeeLinkTypeDTO>> GetAllAmazonFeeLinkTypeAsync()
{
var result = new List<AmazonFeeLinkTypeDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<AmazonFeeLinkType>()
.Select(_ => new AmazonFeeLinkTypeDTO()
 {
Id = _.Id,
LinkType = _.LinkType,
LinkCode = _.LinkCode,
Clicks = _.Clicks,
ProductOrdered = _.ProductOrdered,
Conversion = _.Conversion,
ProductOrderedAmount = _.ProductOrderedAmount,
ProductShipped = _.ProductShipped,
Earnings = _.Earnings
}).OrderBy(_ => _.Id).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonFeeLinkTypeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
AmazonFeeLinkType newRecord = new AmazonFeeLinkType(uow);
newRecord.Id = amazonFeeLinkTypeDTO.Id;
newRecord.LinkType = amazonFeeLinkTypeDTO.LinkType;
newRecord.LinkCode = amazonFeeLinkTypeDTO.LinkCode;
newRecord.Clicks = amazonFeeLinkTypeDTO.Clicks;
newRecord.ProductOrdered = amazonFeeLinkTypeDTO.ProductOrdered;
newRecord.Conversion = amazonFeeLinkTypeDTO.Conversion;
newRecord.ProductOrderedAmount = amazonFeeLinkTypeDTO.ProductOrderedAmount;
newRecord.ProductShipped = amazonFeeLinkTypeDTO.ProductShipped;
newRecord.Earnings = amazonFeeLinkTypeDTO.Earnings;
await uow.CommitChangesAsync();
return newRecord.Id;
}}
async public Task UpdateAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO AmazonFeeLinkTypeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<AmazonFeeLinkType>().Where(_ => _.Id == AmazonFeeLinkTypeDTO.Id).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.Id = AmazonFeeLinkTypeDTO.Id;
recordToUpdate.LinkType = AmazonFeeLinkTypeDTO.LinkType;
recordToUpdate.LinkCode = AmazonFeeLinkTypeDTO.LinkCode;
recordToUpdate.Clicks = AmazonFeeLinkTypeDTO.Clicks;
recordToUpdate.ProductOrdered = AmazonFeeLinkTypeDTO.ProductOrdered;
recordToUpdate.Conversion = AmazonFeeLinkTypeDTO.Conversion;
recordToUpdate.ProductOrderedAmount = AmazonFeeLinkTypeDTO.ProductOrderedAmount;
recordToUpdate.ProductShipped = AmazonFeeLinkTypeDTO.ProductShipped;
recordToUpdate.Earnings = AmazonFeeLinkTypeDTO.Earnings;
await uow.CommitChangesAsync();
}}}
async public Task DeleteAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonFeeLinkTypeDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<AmazonFeeLinkType>().Where(_ => _.Id == amazonFeeLinkTypeDTO.Id).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
