using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class HostRepository : IHostRepository
{
async public Task<List<HostDTO>> GetAllHostAsync()
{
var result = new List<HostDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Model.Host>()
.Select(_ => new HostDTO()
 {
HostId = _.HostId,
CountryId = _.CountryId,
HostName = _.HostName,
HostUrl = _.HostUrl,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.HostId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateHostAsync(HostDTO hostDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
                Model.Host newRecord = new Model.Host(uow);
newRecord.HostId = hostDTO.HostId;
newRecord.CountryId = hostDTO.CountryId;
newRecord.HostName = hostDTO.HostName;
newRecord.HostUrl = hostDTO.HostUrl;
newRecord.DateCreated = hostDTO.DateCreated;
newRecord.DateUpdated = hostDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.HostId;
}}
async public Task UpdateHostAsync(HostDTO HostDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Model.Host>().Where(_ => _.HostId == HostDTO.HostId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.HostId = HostDTO.HostId;
recordToUpdate.CountryId = HostDTO.CountryId;
recordToUpdate.HostName = HostDTO.HostName;
recordToUpdate.HostUrl = HostDTO.HostUrl;
recordToUpdate.DateCreated = HostDTO.DateCreated;
recordToUpdate.DateUpdated = HostDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteHostAsync(HostDTO hostDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Model.Host>().Where(_ => _.HostId == hostDTO.HostId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
