﻿using BWH_API.DTO;
using BWH_API.Model;
using BWH_API.Repository.IRepository;
using DevExpress.Xpo;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BWH_API.Repository
{
    public class AccountRepository : IAccountRepository
    {

        public IConfiguration _configuration { get; set; }
        public AccountRepository()
        {
             _configuration = new ConfigurationBuilder()
                         .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                         .AddEnvironmentVariables()
                         .Build();
        }

        async public Task<int> Register(AuthenticationDto authentication)
        {
            using (var uow = ConnectionHelper.CreateUnitOfWork())
            {
                Authentication newRecord = new Authentication(uow);
                newRecord.Login = authentication.Login;
                newRecord.Password = EncodePasswordToBase64(authentication.Password);
                newRecord.AuthenticationRoleId = authentication.AuthenticationRoleId;
                newRecord.DateCreated = DateTime.UtcNow;
                newRecord.UpdatedDate = DateTime.UtcNow;
                // Save the account object to the database
                uow.CommitChanges();
                return newRecord.AuthenticationId;
            }

        }
        async public Task<object> Login(AuthenticationDto authentication)
        {
            using (var uow = ConnectionHelper.CreateUnitOfWork())
            {
                var user = uow.Query<Authentication>()
                 .FirstOrDefault(a => a.Login == authentication.Login && a.Password == EncodePasswordToBase64(authentication.Password));
              
                if (user != null)
                {
                    var u = (from auth in uow.Query<Authentication>()
                             join role in uow.Query<AuthenticationRole>() on auth.AuthenticationRoleId equals role.AuthenticationRoleId
                             where auth.Login == authentication.Login && auth.Password == EncodePasswordToBase64(authentication.Password)
                             select new
                             {
                                 Login = auth.Login,
                                 AuthenticationId = auth.AuthenticationId,
                                 Role = role.Title
                             }).FirstOrDefault();
                    return new { status = "ok", message = "Successfully Logged In", accessToken = GetToken(u) };
                }
                else
                {
                    return new { status = "invalid", message = "Invalid Credentials" };
                }

            }


        }
        private string GetToken(dynamic authentication)
        {

            var claims = new[] {
                    new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                    new Claim("UserId", authentication.AuthenticationId.ToString()),
                    new Claim("Name", authentication.Login),
                    new Claim(ClaimTypes.Role,authentication.Role)

                };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                _configuration["Jwt:Issuer"],
                _configuration["Jwt:Audience"],
                claims,
                expires: DateTime.UtcNow.AddDays(1),
                signingCredentials: signIn);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        private static string EncodePasswordToBase64(string password)
        {
            try
            {
                byte[] encData_byte = new byte[password.Length];
                encData_byte = System.Text.Encoding.UTF8.GetBytes(password);
                string encodedData = Convert.ToBase64String(encData_byte);
                return encodedData;
            }
            catch (Exception ex)
            {
                throw new Exception("Error in base64Encode" + ex.Message);
            }
        }
        private string DecodeFrom64(string encodedData)
        {
            System.Text.UTF8Encoding encoder = new System.Text.UTF8Encoding();
            System.Text.Decoder utf8Decode = encoder.GetDecoder();
            byte[] todecode_byte = Convert.FromBase64String(encodedData);
            int charCount = utf8Decode.GetCharCount(todecode_byte, 0, todecode_byte.Length);
            char[] decoded_char = new char[charCount];
            utf8Decode.GetChars(todecode_byte, 0, todecode_byte.Length, decoded_char, 0);
            string result = new String(decoded_char);
            return result;
        }

    }
}
