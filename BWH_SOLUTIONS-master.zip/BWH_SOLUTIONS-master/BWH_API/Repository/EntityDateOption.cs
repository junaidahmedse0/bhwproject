using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class EntityDateOptionRepository : IEntityDateOptionRepository
{
async public Task<List<EntityDateOptionDTO>> GetAllEntityDateOptionAsync()
{
var result = new List<EntityDateOptionDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<EntityDateOption>()
.Select(_ => new EntityDateOptionDTO()
 {
EntityDateOptionId = _.EntityDateOptionId,
EntityId = _.EntityId,
DateOptionId = _.DateOptionId,
Title = _.Title,
StartingDate = _.StartingDate,
EndingDate = _.EndingDate,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.EntityDateOptionId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateEntityDateOptionAsync(EntityDateOptionDTO entityDateOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
EntityDateOption newRecord = new EntityDateOption(uow);
newRecord.EntityDateOptionId = entityDateOptionDTO.EntityDateOptionId;
newRecord.EntityId = entityDateOptionDTO.EntityId;
newRecord.DateOptionId = entityDateOptionDTO.DateOptionId;
newRecord.Title = entityDateOptionDTO.Title;
newRecord.StartingDate = entityDateOptionDTO.StartingDate;
newRecord.EndingDate = entityDateOptionDTO.EndingDate;
newRecord.DateCreated = entityDateOptionDTO.DateCreated;
newRecord.DateUpdated = entityDateOptionDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.EntityDateOptionId;
}}
async public Task UpdateEntityDateOptionAsync(EntityDateOptionDTO EntityDateOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<EntityDateOption>().Where(_ => _.EntityDateOptionId == EntityDateOptionDTO.EntityDateOptionId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.EntityDateOptionId = EntityDateOptionDTO.EntityDateOptionId;
recordToUpdate.EntityId = EntityDateOptionDTO.EntityId;
recordToUpdate.DateOptionId = EntityDateOptionDTO.DateOptionId;
recordToUpdate.Title = EntityDateOptionDTO.Title;
recordToUpdate.StartingDate = EntityDateOptionDTO.StartingDate;
recordToUpdate.EndingDate = EntityDateOptionDTO.EndingDate;
recordToUpdate.DateCreated = EntityDateOptionDTO.DateCreated;
recordToUpdate.DateUpdated = EntityDateOptionDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteEntityDateOptionAsync(EntityDateOptionDTO entityDateOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<EntityDateOption>().Where(_ => _.EntityDateOptionId == entityDateOptionDTO.EntityDateOptionId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
