using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class TechnicalOptionRepository : ITechnicalOptionRepository
{
async public Task<List<TechnicalOptionDTO>> GetAllTechnicalOptionAsync()
{
var result = new List<TechnicalOptionDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<TechnicalOption>()
.Select(_ => new TechnicalOptionDTO()
 {
TechnicalOptionId = _.TechnicalOptionId,
EntityTypeId = _.EntityTypeId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.TechnicalOptionId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateTechnicalOptionAsync(TechnicalOptionDTO technicalOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
TechnicalOption newRecord = new TechnicalOption(uow);
newRecord.TechnicalOptionId = technicalOptionDTO.TechnicalOptionId;
newRecord.EntityTypeId = technicalOptionDTO.EntityTypeId;
newRecord.Title = technicalOptionDTO.Title;
newRecord.DateCreated = technicalOptionDTO.DateCreated;
newRecord.DateUpdated = technicalOptionDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.TechnicalOptionId;
}}
async public Task UpdateTechnicalOptionAsync(TechnicalOptionDTO TechnicalOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<TechnicalOption>().Where(_ => _.TechnicalOptionId == TechnicalOptionDTO.TechnicalOptionId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.TechnicalOptionId = TechnicalOptionDTO.TechnicalOptionId;
recordToUpdate.EntityTypeId = TechnicalOptionDTO.EntityTypeId;
recordToUpdate.Title = TechnicalOptionDTO.Title;
recordToUpdate.DateCreated = TechnicalOptionDTO.DateCreated;
recordToUpdate.DateUpdated = TechnicalOptionDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteTechnicalOptionAsync(TechnicalOptionDTO technicalOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<TechnicalOption>().Where(_ => _.TechnicalOptionId == technicalOptionDTO.TechnicalOptionId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
