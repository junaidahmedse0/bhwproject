using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class TechnicalStatusRepository : ITechnicalStatusRepository
{
async public Task<List<TechnicalStatusDTO>> GetAllTechnicalStatusAsync()
{
var result = new List<TechnicalStatusDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<TechnicalStatus>()
.Select(_ => new TechnicalStatusDTO()
 {
TechnicalStatusId = _.TechnicalStatusId,
EntityTypeId = _.EntityTypeId,
Title = _.Title,
DisplayOrder = _.DisplayOrder,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.TechnicalStatusId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateTechnicalStatusAsync(TechnicalStatusDTO technicalStatusDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
TechnicalStatus newRecord = new TechnicalStatus(uow);
newRecord.TechnicalStatusId = technicalStatusDTO.TechnicalStatusId;
newRecord.EntityTypeId = technicalStatusDTO.EntityTypeId;
newRecord.Title = technicalStatusDTO.Title;
newRecord.DisplayOrder = technicalStatusDTO.DisplayOrder;
newRecord.DateCreated = technicalStatusDTO.DateCreated;
newRecord.DateUpdated = technicalStatusDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.TechnicalStatusId;
}}
async public Task UpdateTechnicalStatusAsync(TechnicalStatusDTO TechnicalStatusDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<TechnicalStatus>().Where(_ => _.TechnicalStatusId == TechnicalStatusDTO.TechnicalStatusId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.TechnicalStatusId = TechnicalStatusDTO.TechnicalStatusId;
recordToUpdate.EntityTypeId = TechnicalStatusDTO.EntityTypeId;
recordToUpdate.Title = TechnicalStatusDTO.Title;
recordToUpdate.DisplayOrder = TechnicalStatusDTO.DisplayOrder;
recordToUpdate.DateCreated = TechnicalStatusDTO.DateCreated;
recordToUpdate.DateUpdated = TechnicalStatusDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteTechnicalStatusAsync(TechnicalStatusDTO technicalStatusDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<TechnicalStatus>().Where(_ => _.TechnicalStatusId == technicalStatusDTO.TechnicalStatusId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
