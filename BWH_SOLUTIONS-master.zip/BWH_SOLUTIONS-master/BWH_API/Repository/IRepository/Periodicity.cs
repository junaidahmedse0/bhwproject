using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IPeriodicityRepository
{
Task<List<PeriodicityDTO>> GetAllPeriodicityAsync();
Task<int> CreatePeriodicityAsync(PeriodicityDTO periodicityDTO);
Task UpdatePeriodicityAsync(PeriodicityDTO periodicityDTO);
 Task DeletePeriodicityAsync(PeriodicityDTO periodicityDTO);
}}
