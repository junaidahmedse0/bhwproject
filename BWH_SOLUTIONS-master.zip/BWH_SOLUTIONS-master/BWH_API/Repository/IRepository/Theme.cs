using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IThemeRepository
{
Task<List<ThemeDTO>> GetAllThemeAsync();
Task<int> CreateThemeAsync(ThemeDTO themeDTO);
Task UpdateThemeAsync(ThemeDTO themeDTO);
 Task DeleteThemeAsync(ThemeDTO themeDTO);
}}
