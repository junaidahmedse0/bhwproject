using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IPersonRepository
{
Task<List<PersonDTO>> GetAllPersonAsync();
Task<int> CreatePersonAsync(PersonDTO personDTO);
Task UpdatePersonAsync(PersonDTO personDTO);
 Task DeletePersonAsync(PersonDTO personDTO);
}}
