using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface ITechnicalOptionRepository
{
Task<List<TechnicalOptionDTO>> GetAllTechnicalOptionAsync();
Task<int> CreateTechnicalOptionAsync(TechnicalOptionDTO technicaloptionDTO);
Task UpdateTechnicalOptionAsync(TechnicalOptionDTO technicaloptionDTO);
 Task DeleteTechnicalOptionAsync(TechnicalOptionDTO technicaloptionDTO);
}}
