using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IAmazonFeeOrdersRepository
{
Task<List<AmazonFeeOrdersDTO>> GetAllAmazonFeeOrdersAsync();
Task<int> CreateAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonfeeordersDTO);
Task UpdateAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonfeeordersDTO);
 Task DeleteAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonfeeordersDTO);
}}
