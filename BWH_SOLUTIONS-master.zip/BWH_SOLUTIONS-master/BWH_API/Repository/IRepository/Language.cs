using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface ILanguageRepository
{
Task<List<LanguageDTO>> GetAllLanguageAsync();
Task<int> CreateLanguageAsync(LanguageDTO languageDTO);
Task UpdateLanguageAsync(LanguageDTO languageDTO);
 Task DeleteLanguageAsync(LanguageDTO languageDTO);
}}
