using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IMainRequestRepository
{
Task<List<MainRequestDTO>> GetAllMainRequestAsync();
Task<int> CreateMainRequestAsync(MainRequestDTO mainrequestDTO);
Task UpdateMainRequestAsync(MainRequestDTO mainrequestDTO);
 Task DeleteMainRequestAsync(MainRequestDTO mainrequestDTO);
}}
