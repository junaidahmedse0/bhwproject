using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IFamilyProjectRepository
{
Task<List<FamilyProjectDTO>> GetAllFamilyProjectAsync();
Task<int> CreateFamilyProjectAsync(FamilyProjectDTO familyprojectDTO);
Task UpdateFamilyProjectAsync(FamilyProjectDTO familyprojectDTO);
 Task DeleteFamilyProjectAsync(FamilyProjectDTO familyprojectDTO);
}}
