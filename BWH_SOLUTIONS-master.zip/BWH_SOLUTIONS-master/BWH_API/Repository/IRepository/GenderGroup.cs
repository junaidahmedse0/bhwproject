using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IGenderGroupRepository
{
Task<List<GenderGroupDTO>> GetAllGenderGroupAsync();
Task<int> CreateGenderGroupAsync(GenderGroupDTO gendergroupDTO);
Task UpdateGenderGroupAsync(GenderGroupDTO gendergroupDTO);
 Task DeleteGenderGroupAsync(GenderGroupDTO gendergroupDTO);
}}
