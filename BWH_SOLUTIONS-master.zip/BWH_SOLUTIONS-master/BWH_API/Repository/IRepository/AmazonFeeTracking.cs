using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IAmazonFeeTrackingRepository
{
Task<List<AmazonFeeTrackingDTO>> GetAllAmazonFeeTrackingAsync();
Task<int> CreateAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonfeetrackingDTO);
Task UpdateAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonfeetrackingDTO);
 Task DeleteAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonfeetrackingDTO);
}}
