﻿using BWH_API.DTO;

namespace BWH_API.Repository.IRepository
{
    public interface IAccountRepository
    {
        Task<int> Register(AuthenticationDto authentication);
        Task<Object> Login(AuthenticationDto authentication);

    }
}
