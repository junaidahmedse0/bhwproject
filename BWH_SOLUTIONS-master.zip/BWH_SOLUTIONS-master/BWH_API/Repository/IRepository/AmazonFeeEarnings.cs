using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IAmazonFeeEarningsRepository
{
Task<List<AmazonFeeEarningsDTO>> GetAllAmazonFeeEarningsAsync();
Task<int> CreateAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonfeeearningsDTO);
Task UpdateAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonfeeearningsDTO);
 Task DeleteAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonfeeearningsDTO);
}}
