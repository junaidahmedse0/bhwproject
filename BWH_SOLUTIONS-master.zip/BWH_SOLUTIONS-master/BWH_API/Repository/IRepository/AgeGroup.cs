using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IAgeGroupRepository
{
Task<List<AgeGroupDTO>> GetAllAgeGroupAsync();
Task<int> CreateAgeGroupAsync(AgeGroupDTO agegroupDTO);
Task UpdateAgeGroupAsync(AgeGroupDTO agegroupDTO);
 Task DeleteAgeGroupAsync(AgeGroupDTO agegroupDTO);
}}
