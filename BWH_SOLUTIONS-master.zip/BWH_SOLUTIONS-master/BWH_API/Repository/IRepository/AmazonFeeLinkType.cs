using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IAmazonFeeLinkTypeRepository
{
Task<List<AmazonFeeLinkTypeDTO>> GetAllAmazonFeeLinkTypeAsync();
Task<int> CreateAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonfeelinktypeDTO);
Task UpdateAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonfeelinktypeDTO);
 Task DeleteAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonfeelinktypeDTO);
}}
