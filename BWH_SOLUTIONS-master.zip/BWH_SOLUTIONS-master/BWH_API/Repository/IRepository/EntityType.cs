using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IEntityTypeRepository
{
Task<List<EntityTypeDTO>> GetAllEntityTypeAsync();
Task<int> CreateEntityTypeAsync(EntityTypeDTO entitytypeDTO);
Task UpdateEntityTypeAsync(EntityTypeDTO entitytypeDTO);
 Task DeleteEntityTypeAsync(EntityTypeDTO entitytypeDTO);
}}
