using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IFamilyRepository
{
Task<List<FamilyDTO>> GetAllFamilyAsync();
Task<int> CreateFamilyAsync(FamilyDTO familyDTO);
Task UpdateFamilyAsync(FamilyDTO familyDTO);
 Task DeleteFamilyAsync(FamilyDTO familyDTO);
}}
