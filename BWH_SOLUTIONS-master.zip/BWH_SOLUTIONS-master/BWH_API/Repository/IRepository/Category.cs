using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface ICategoryRepository
{
Task<List<CategoryDTO>> GetAllCategoryAsync();
Task<int> CreateCategoryAsync(CategoryDTO categoryDTO);
Task UpdateCategoryAsync(CategoryDTO categoryDTO);
 Task DeleteCategoryAsync(CategoryDTO categoryDTO);
}}
