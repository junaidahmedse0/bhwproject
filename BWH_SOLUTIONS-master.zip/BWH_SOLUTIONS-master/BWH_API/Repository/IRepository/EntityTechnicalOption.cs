using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IEntityTechnicalOptionRepository
{
Task<List<EntityTechnicalOptionDTO>> GetAllEntityTechnicalOptionAsync();
Task<int> CreateEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entitytechnicaloptionDTO);
Task UpdateEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entitytechnicaloptionDTO);
 Task DeleteEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entitytechnicaloptionDTO);
}}
