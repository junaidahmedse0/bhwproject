using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IDateOptionRepository
{
Task<List<DateOptionDTO>> GetAllDateOptionAsync();
Task<int> CreateDateOptionAsync(DateOptionDTO dateoptionDTO);
Task UpdateDateOptionAsync(DateOptionDTO dateoptionDTO);
 Task DeleteDateOptionAsync(DateOptionDTO dateoptionDTO);
}}
