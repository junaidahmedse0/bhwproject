using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface ITrackingCodeRepository
{
Task<List<TrackingCodeDTO>> GetAllTrackingCodeAsync();
Task<int> CreateTrackingCodeAsync(TrackingCodeDTO trackingcodeDTO);
Task UpdateTrackingCodeAsync(TrackingCodeDTO trackingcodeDTO);
 Task DeleteTrackingCodeAsync(TrackingCodeDTO trackingcodeDTO);
}}
