using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IBusinessSectorRepository
{
Task<List<BusinessSectorDTO>> GetAllBusinessSectorAsync();
Task<int> CreateBusinessSectorAsync(BusinessSectorDTO businesssectorDTO);
Task UpdateBusinessSectorAsync(BusinessSectorDTO businesssectorDTO);
 Task DeleteBusinessSectorAsync(BusinessSectorDTO businesssectorDTO);
}}
