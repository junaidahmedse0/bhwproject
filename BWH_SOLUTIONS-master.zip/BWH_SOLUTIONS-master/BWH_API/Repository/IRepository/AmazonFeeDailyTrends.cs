using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IAmazonFeeDailyTrendsRepository
{
Task<List<AmazonFeeDailyTrendsDTO>> GetAllAmazonFeeDailyTrendsAsync();
Task<int> CreateAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonfeedailytrendsDTO);
Task UpdateAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonfeedailytrendsDTO);
 Task DeleteAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonfeedailytrendsDTO);
}}
