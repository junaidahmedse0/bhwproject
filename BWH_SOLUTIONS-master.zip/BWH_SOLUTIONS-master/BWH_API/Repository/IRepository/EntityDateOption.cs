using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IEntityDateOptionRepository
{
Task<List<EntityDateOptionDTO>> GetAllEntityDateOptionAsync();
Task<int> CreateEntityDateOptionAsync(EntityDateOptionDTO entitydateoptionDTO);
Task UpdateEntityDateOptionAsync(EntityDateOptionDTO entitydateoptionDTO);
 Task DeleteEntityDateOptionAsync(EntityDateOptionDTO entitydateoptionDTO);
}}
