using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IProjectRepository
{
Task<List<ProjectDTO>> GetAllProjectAsync();
Task<int> CreateProjectAsync(ProjectDTO projectDTO);
Task UpdateProjectAsync(ProjectDTO projectDTO);
 Task DeleteProjectAsync(ProjectDTO projectDTO);
}}
