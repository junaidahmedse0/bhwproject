using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IExpertiseAreaRepository
{
Task<List<ExpertiseAreaDTO>> GetAllExpertiseAreaAsync();
Task<int> CreateExpertiseAreaAsync(ExpertiseAreaDTO expertiseareaDTO);
Task UpdateExpertiseAreaAsync(ExpertiseAreaDTO expertiseareaDTO);
 Task DeleteExpertiseAreaAsync(ExpertiseAreaDTO expertiseareaDTO);
}}
