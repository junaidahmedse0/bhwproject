using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IsysdiagramsRepository
{
Task<List<sysdiagramsDTO>> GetAllsysdiagramsAsync();
Task<int> CreatesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO);
Task UpdatesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO);
 Task DeletesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO);
}}
