using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IHostRepository
{
Task<List<HostDTO>> GetAllHostAsync();
Task<int> CreateHostAsync(HostDTO hostDTO);
Task UpdateHostAsync(HostDTO hostDTO);
 Task DeleteHostAsync(HostDTO hostDTO);
}}
