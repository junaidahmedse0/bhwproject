using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface ICountryRepository
{
Task<List<CountryDTO>> GetAllCountryAsync();
Task<int> CreateCountryAsync(CountryDTO countryDTO);
Task UpdateCountryAsync(CountryDTO countryDTO);
 Task DeleteCountryAsync(CountryDTO countryDTO);
}}
