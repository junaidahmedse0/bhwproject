using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface ITechnicalStatusRepository
{
Task<List<TechnicalStatusDTO>> GetAllTechnicalStatusAsync();
Task<int> CreateTechnicalStatusAsync(TechnicalStatusDTO technicalstatusDTO);
Task UpdateTechnicalStatusAsync(TechnicalStatusDTO technicalstatusDTO);
 Task DeleteTechnicalStatusAsync(TechnicalStatusDTO technicalstatusDTO);
}}
