using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IRegistrarRepository
{
Task<List<RegistrarDTO>> GetAllRegistrarAsync();
Task<int> CreateRegistrarAsync(RegistrarDTO registrarDTO);
Task UpdateRegistrarAsync(RegistrarDTO registrarDTO);
 Task DeleteRegistrarAsync(RegistrarDTO registrarDTO);
}}
