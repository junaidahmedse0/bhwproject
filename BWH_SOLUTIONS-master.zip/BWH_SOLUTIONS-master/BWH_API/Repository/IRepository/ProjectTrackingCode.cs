using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IProjectTrackingCodeRepository
{
Task<List<ProjectTrackingCodeDTO>> GetAllProjectTrackingCodeAsync();
Task<int> CreateProjectTrackingCodeAsync(ProjectTrackingCodeDTO projecttrackingcodeDTO);
Task UpdateProjectTrackingCodeAsync(ProjectTrackingCodeDTO projecttrackingcodeDTO);
 Task DeleteProjectTrackingCodeAsync(ProjectTrackingCodeDTO projecttrackingcodeDTO);
}}
