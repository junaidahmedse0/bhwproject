using System.Collections.Generic;
using System.Threading.Tasks;
using BWH_API.DTO;
namespace BWH_API.Repository.IRepository
{
public interface IDomainNameRepository
{
Task<List<DomainNameDTO>> GetAllDomainNameAsync();
Task<int> CreateDomainNameAsync(DomainNameDTO domainnameDTO);
Task UpdateDomainNameAsync(DomainNameDTO domainnameDTO);
 Task DeleteDomainNameAsync(DomainNameDTO domainnameDTO);
}}
