using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class AmazonFeeEarningsRepository : IAmazonFeeEarningsRepository
{
async public Task<List<AmazonFeeEarningsDTO>> GetAllAmazonFeeEarningsAsync()
{
var result = new List<AmazonFeeEarningsDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<AmazonFeeEarnings>()
.Select(_ => new AmazonFeeEarningsDTO()
 {
Id = _.Id,
Category = _.Category,
Product = _.Product,
AmazonStandardIdentificationNumber = _.AmazonStandardIdentificationNumber,
Seller = _.Seller,
TrackingId = _.TrackingId,
ShippingDate = _.ShippingDate,
Price = _.Price,
ProductShipped = _.ProductShipped,
ProductReturned = _.ProductReturned,
Revenue = _.Revenue,
AdvertisingFee = _.AdvertisingFee,
Device = _.Device,
Direct = _.Direct
}).OrderBy(_ => _.Id).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonFeeEarningsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
AmazonFeeEarnings newRecord = new AmazonFeeEarnings(uow);
newRecord.Id = amazonFeeEarningsDTO.Id;
newRecord.Category = amazonFeeEarningsDTO.Category;
newRecord.Product = amazonFeeEarningsDTO.Product;
newRecord.AmazonStandardIdentificationNumber = amazonFeeEarningsDTO.AmazonStandardIdentificationNumber;
newRecord.Seller = amazonFeeEarningsDTO.Seller;
newRecord.TrackingId = amazonFeeEarningsDTO.TrackingId;
newRecord.ShippingDate = amazonFeeEarningsDTO.ShippingDate;
newRecord.Price = amazonFeeEarningsDTO.Price;
newRecord.ProductShipped = amazonFeeEarningsDTO.ProductShipped;
newRecord.ProductReturned = amazonFeeEarningsDTO.ProductReturned;
newRecord.Revenue = amazonFeeEarningsDTO.Revenue;
newRecord.AdvertisingFee = amazonFeeEarningsDTO.AdvertisingFee;
newRecord.Device = amazonFeeEarningsDTO.Device;
newRecord.Direct = amazonFeeEarningsDTO.Direct;
await uow.CommitChangesAsync();
return newRecord.Id;
}}
async public Task UpdateAmazonFeeEarningsAsync(AmazonFeeEarningsDTO AmazonFeeEarningsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<AmazonFeeEarnings>().Where(_ => _.Id == AmazonFeeEarningsDTO.Id).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.Id = AmazonFeeEarningsDTO.Id;
recordToUpdate.Category = AmazonFeeEarningsDTO.Category;
recordToUpdate.Product = AmazonFeeEarningsDTO.Product;
recordToUpdate.AmazonStandardIdentificationNumber = AmazonFeeEarningsDTO.AmazonStandardIdentificationNumber;
recordToUpdate.Seller = AmazonFeeEarningsDTO.Seller;
recordToUpdate.TrackingId = AmazonFeeEarningsDTO.TrackingId;
recordToUpdate.ShippingDate = AmazonFeeEarningsDTO.ShippingDate;
recordToUpdate.Price = AmazonFeeEarningsDTO.Price;
recordToUpdate.ProductShipped = AmazonFeeEarningsDTO.ProductShipped;
recordToUpdate.ProductReturned = AmazonFeeEarningsDTO.ProductReturned;
recordToUpdate.Revenue = AmazonFeeEarningsDTO.Revenue;
recordToUpdate.AdvertisingFee = AmazonFeeEarningsDTO.AdvertisingFee;
recordToUpdate.Device = AmazonFeeEarningsDTO.Device;
recordToUpdate.Direct = AmazonFeeEarningsDTO.Direct;
await uow.CommitChangesAsync();
}}}
async public Task DeleteAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonFeeEarningsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<AmazonFeeEarnings>().Where(_ => _.Id == amazonFeeEarningsDTO.Id).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
