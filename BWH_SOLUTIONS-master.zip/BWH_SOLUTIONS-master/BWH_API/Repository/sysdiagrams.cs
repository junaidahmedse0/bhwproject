using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class sysdiagramsRepository : IsysdiagramsRepository
{
async public Task<List<sysdiagramsDTO>> GetAllsysdiagramsAsync()
{
var result = new List<sysdiagramsDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<sysdiagrams>()
.Select(_ => new sysdiagramsDTO()
 {
name = _.name,
principal_id = _.principal_id,
diagram_id = _.diagram_id,
version = _.version,
definition = _.definition
}).OrderBy(_ => _.diagram_id).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreatesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
sysdiagrams newRecord = new sysdiagrams(uow);
newRecord.name = sysdiagramsDTO.name;
newRecord.principal_id = sysdiagramsDTO.principal_id;
newRecord.diagram_id = sysdiagramsDTO.diagram_id;
newRecord.version = sysdiagramsDTO.version;
newRecord.definition = sysdiagramsDTO.definition;
await uow.CommitChangesAsync();
return newRecord.diagram_id;
}}
async public Task UpdatesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<sysdiagrams>().Where(_ => _.diagram_id == sysdiagramsDTO.diagram_id).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.name = sysdiagramsDTO.name;
recordToUpdate.principal_id = sysdiagramsDTO.principal_id;
recordToUpdate.diagram_id = sysdiagramsDTO.diagram_id;
recordToUpdate.version = sysdiagramsDTO.version;
recordToUpdate.definition = sysdiagramsDTO.definition;
await uow.CommitChangesAsync();
}}}
async public Task DeletesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<sysdiagrams>().Where(_ => _.diagram_id == sysdiagramsDTO.diagram_id).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
