using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class DateOptionRepository : IDateOptionRepository
{
async public Task<List<DateOptionDTO>> GetAllDateOptionAsync()
{
var result = new List<DateOptionDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<DateOption>()
.Select(_ => new DateOptionDTO()
 {
DateOptionId = _.DateOptionId,
EntityTypeId = _.EntityTypeId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.DateOptionId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateDateOptionAsync(DateOptionDTO dateOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
DateOption newRecord = new DateOption(uow);
newRecord.DateOptionId = dateOptionDTO.DateOptionId;
newRecord.EntityTypeId = dateOptionDTO.EntityTypeId;
newRecord.Title = dateOptionDTO.Title;
newRecord.DateCreated = dateOptionDTO.DateCreated;
newRecord.DateUpdated = dateOptionDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.DateOptionId;
}}
async public Task UpdateDateOptionAsync(DateOptionDTO DateOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<DateOption>().Where(_ => _.DateOptionId == DateOptionDTO.DateOptionId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.DateOptionId = DateOptionDTO.DateOptionId;
recordToUpdate.EntityTypeId = DateOptionDTO.EntityTypeId;
recordToUpdate.Title = DateOptionDTO.Title;
recordToUpdate.DateCreated = DateOptionDTO.DateCreated;
recordToUpdate.DateUpdated = DateOptionDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteDateOptionAsync(DateOptionDTO dateOptionDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<DateOption>().Where(_ => _.DateOptionId == dateOptionDTO.DateOptionId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
