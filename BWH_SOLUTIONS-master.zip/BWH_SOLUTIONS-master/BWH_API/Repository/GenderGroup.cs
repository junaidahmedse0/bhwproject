using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class GenderGroupRepository : IGenderGroupRepository
{
async public Task<List<GenderGroupDTO>> GetAllGenderGroupAsync()
{
var result = new List<GenderGroupDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<GenderGroup>()
.Select(_ => new GenderGroupDTO()
 {
GenderGroupId = _.GenderGroupId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.GenderGroupId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateGenderGroupAsync(GenderGroupDTO genderGroupDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
GenderGroup newRecord = new GenderGroup(uow);
newRecord.GenderGroupId = genderGroupDTO.GenderGroupId;
newRecord.Title = genderGroupDTO.Title;
newRecord.DateCreated = genderGroupDTO.DateCreated;
newRecord.DateUpdated = genderGroupDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.GenderGroupId;
}}
async public Task UpdateGenderGroupAsync(GenderGroupDTO GenderGroupDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<GenderGroup>().Where(_ => _.GenderGroupId == GenderGroupDTO.GenderGroupId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.GenderGroupId = GenderGroupDTO.GenderGroupId;
recordToUpdate.Title = GenderGroupDTO.Title;
recordToUpdate.DateCreated = GenderGroupDTO.DateCreated;
recordToUpdate.DateUpdated = GenderGroupDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteGenderGroupAsync(GenderGroupDTO genderGroupDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<GenderGroup>().Where(_ => _.GenderGroupId == genderGroupDTO.GenderGroupId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
