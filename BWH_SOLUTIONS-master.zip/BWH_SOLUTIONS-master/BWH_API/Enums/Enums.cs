﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BWH_API.Enums
{
    public class Enums
    {
        public enum LogLevel
        {
            Error = 1,
            Info,
            Warn,
            Debug,
            Trace
        }

        public enum AuditActionTypes
        {
            Edit,
            Open,
            Close,
            Publish,
            Delete,
            Create
        }
    }
}