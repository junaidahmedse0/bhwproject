namespace BWH_API.DTO
{
public class MainRequestDTO
{
public int MainRequestId {get; set;}
public int MainRequestParentId {get; set;}
public int LanguageId {get; set;}
public string MainRequest {get; set;}
public string LexicalField1 {get; set;}
public string LexicalField2 {get; set;}
public string LexicalField3 {get; set;}
public string LexicalField4 {get; set;}
public string LexicalField5 {get; set;}
public string LexicalField6 {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
