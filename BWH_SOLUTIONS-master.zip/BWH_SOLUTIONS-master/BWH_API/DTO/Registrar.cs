namespace BWH_API.DTO
{
public class RegistrarDTO
{
public int RegistrarId {get; set;}
public string Name {get; set;}
public string Url {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
