namespace BWH_API.DTO
{
public class LanguageDTO
{
public int LanguageId {get; set;}
public string Title {get; set;}
public string Code {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
