namespace BWH_API.DTO
{
public class HostDTO
{
public int HostId {get; set;}
public int CountryId {get; set;}
public string HostName {get; set;}
public string HostUrl {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
