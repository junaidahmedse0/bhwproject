namespace BWH_API.DTO
{
public class AmazonFeeDailyTrendsDTO
{
public int Id {get; set;}
public string OperationDate {get; set;}
public string Clicks {get; set;}
public string ProductOrdered {get; set;}
public string ProductShipped {get; set;}
public string Conversion {get; set;}
}}
