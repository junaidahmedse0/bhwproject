namespace BWH_API.DTO
{
public class ThemeDTO
{
public int ThemeId {get; set;}
public int TechnicalStatusId {get; set;}
public int CreatorId {get; set;}
public string Title {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
