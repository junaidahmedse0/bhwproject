namespace BWH_API.DTO
{
public class GenderGroupDTO
{
public int GenderGroupId {get; set;}
public string Title {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
