namespace BWH_API.DTO
{
public class AmazonFeeOrdersDTO
{
public int Id {get; set;}
public string Category {get; set;}
public string Product {get; set;}
public string AmazonStandardIdentificationNumber {get; set;}
public string OperationDate {get; set;}
public string Quantity {get; set;}
public string Price {get; set;}
public string LinkType {get; set;}
public string Tag {get; set;}
public string LinkProductOrder {get; set;}
public string Device {get; set;}
}}
