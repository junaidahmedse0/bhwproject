namespace BWH_API.DTO
{
public class AmazonFeeTrackingDTO
{
public int Id {get; set;}
public string Tag {get; set;}
public string Clicks {get; set;}
public string ProductOrdered {get; set;}
public string ProductShipped {get; set;}
public string ProductOrderedAmount {get; set;}
public string Earnings {get; set;}
}}
