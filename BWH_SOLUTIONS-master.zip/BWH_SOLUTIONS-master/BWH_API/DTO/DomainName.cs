namespace BWH_API.DTO
{
public class DomainNameDTO
{
public int DomainNameId {get; set;}
public int RegistrarId {get; set;}
public string Title {get; set;}
public string SubscriptionStartingDate {get; set;}
public string NextRenewalDate {get; set;}
public string Price {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
public int TechnicalStatusId {get; set;}
}}
