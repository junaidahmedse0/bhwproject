﻿namespace BWH_API.DTO
{
    public class AuthenticationDto
    {
        public int AuthenticationId { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public int AuthenticationRoleId { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime UpdatedDate { get; set; }

    }
}
