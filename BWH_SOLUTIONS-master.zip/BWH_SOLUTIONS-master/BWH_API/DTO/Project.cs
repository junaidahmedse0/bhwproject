namespace BWH_API.DTO
{
public class ProjectDTO
{
public int ProjectId {get; set;}
public int CategoryId {get; set;}
public int BusinessSectorId {get; set;}
public int ThemeId {get; set;}
public int TechnicalStatusId {get; set;}
public int LanguageId {get; set;}
public int AgeGroupId {get; set;}
public int GenderGroupId {get; set;}
public int HostId {get; set;}
public int DomainNameId {get; set;}
public string Code {get; set;}
public string Title {get; set;}
public string Description {get; set;}
public string Folder {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
