namespace BWH_API.DTO
{
public class PersonDTO
{
public int PersonId {get; set;}
public int ExpertiseAreaId {get; set;}
public int AdditionalExpertiseAreaId {get; set;}
public string Name {get; set;}
public string Mail {get; set;}
public string Info {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
