namespace BWH_API.DTO
{
public class CategoryDTO
{
public int CategoryId {get; set;}
public string Title {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
