namespace BWH_API.DTO
{
public class EntityTechnicalOptionDTO
{
public int EntityTechnicalOptionId {get; set;}
public int EntityId {get; set;}
public int TechnicalOptionId {get; set;}
public string TechnicalOptionValue {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
