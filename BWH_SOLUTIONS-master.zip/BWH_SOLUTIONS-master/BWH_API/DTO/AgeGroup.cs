namespace BWH_API.DTO
{
public class AgeGroupDTO
{
public int AgeGroupId {get; set;}
public string Title {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
