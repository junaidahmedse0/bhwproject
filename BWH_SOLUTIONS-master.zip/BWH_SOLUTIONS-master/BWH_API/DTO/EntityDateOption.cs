namespace BWH_API.DTO
{
public class EntityDateOptionDTO
{
public int EntityDateOptionId {get; set;}
public int EntityId {get; set;}
public int DateOptionId {get; set;}
public string Title {get; set;}
public string StartingDate {get; set;}
public string EndingDate {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
