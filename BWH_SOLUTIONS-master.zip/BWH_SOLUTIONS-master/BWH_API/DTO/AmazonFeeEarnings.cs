namespace BWH_API.DTO
{
public class AmazonFeeEarningsDTO
{
public int Id {get; set;}
public string Category {get; set;}
public string Product {get; set;}
public string AmazonStandardIdentificationNumber {get; set;}
public string Seller {get; set;}
public string TrackingId {get; set;}
public string ShippingDate {get; set;}
public string Price {get; set;}
public string ProductShipped {get; set;}
public string ProductReturned {get; set;}
public string Revenue {get; set;}
public string AdvertisingFee {get; set;}
public string Device {get; set;}
public string Direct {get; set;}
}}
