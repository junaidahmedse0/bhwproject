namespace BWH_API.DTO
{
public class TrackingCodeDTO
{
public int TrackingCodeId {get; set;}
public string Title {get; set;}
public string Tag {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
