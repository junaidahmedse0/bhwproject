namespace BWH_API.DTO
{
public class AmazonFeeLinkTypeDTO
{
public int Id {get; set;}
public string LinkType {get; set;}
public string LinkCode {get; set;}
public string Clicks {get; set;}
public string ProductOrdered {get; set;}
public string Conversion {get; set;}
public string ProductOrderedAmount {get; set;}
public string ProductShipped {get; set;}
public string Earnings {get; set;}
}}
