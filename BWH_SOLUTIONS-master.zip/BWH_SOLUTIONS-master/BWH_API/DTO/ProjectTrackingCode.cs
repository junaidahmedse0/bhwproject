namespace BWH_API.DTO
{
public class ProjectTrackingCodeDTO
{
public int ProjectTrackingCodeId {get; set;}
public int TrackingCodeId {get; set;}
public int ProjectId {get; set;}
public string Code {get; set;}
public DateTime DateCreated {get; set;}
public DateTime DateUpdated {get; set;}
}}
