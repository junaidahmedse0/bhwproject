﻿using BWH_API;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace BWH_API.Utility
{
    public class LogHelper
    {
        public static string GetLoggerMessage<T>(Exception ex, string methodName)
        {
            return GetLoggerMessage<T>(ex.Message, methodName);
        }

        public static string GetLoggerMessage<T>(string message, string methodName)
        {
            StringBuilder loggerMessage = new StringBuilder();

            loggerMessage.AppendLine($"Plugin - {Constants.PLUGIN_APP_CODE}");            
            loggerMessage.AppendLine($"Class : {typeof(T).FullName}");
            loggerMessage.AppendLine($"Method : {methodName}");
            loggerMessage.AppendLine($"Error Message : {message}");

            return loggerMessage.ToString();
        }
    }
}