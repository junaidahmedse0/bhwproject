﻿using BWH_API;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace BWH_API.Utility
{
    public static class DebugLogger
    {
        public static void LogDebugInfo(string logContent)
        {
            try
            {

#if DEBUG
                string path = @"C:\logs\debug-log.txt";
                using (var tw = File.AppendText(path))
                {
                    tw.WriteLine($" {DateTime.UtcNow} Version : {Constants.APP_SCRIPT_VERSION} {Environment.NewLine} {logContent}");
                }
#endif
            }
            catch (Exception)
            {
                //No log, just to avoid breaking the code
            }
        }
    }
}