﻿
namespace BWH_API.Utility
{
    public static class Global 
    {
    }
}
