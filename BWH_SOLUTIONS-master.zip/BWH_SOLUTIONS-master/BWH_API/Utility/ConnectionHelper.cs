﻿using DevExpress.Xpo;
using DevExpress.Xpo.DB;
using DevExpress.Xpo.Metadata;
using BWH_API.Model;
using System;
using Host = BWH_API.Model.Host;

namespace BWH_API.Repository
{
    public class ConnectionHelper
    {
        public static IDataLayer appDataLayer;
        static readonly Type[] PersistentTypes = new Type[] {
            typeof(Category),
            typeof(AgeGroup),
            typeof(BusinessSector),
            typeof(Country),
            typeof(DateOption),
            typeof(DomainName),
            typeof(EntityDateOption),
            typeof(EntityTechnicalOption),
            typeof(EntityType),
            typeof(ExpertiseArea),
            typeof(Family),
            typeof(FamilyProject),
            typeof(GenderGroup),
            typeof(Host),
            typeof(Language),
            typeof(MainRequest),
            typeof(Periodicity),
            typeof(Person),
            typeof(Project),
            typeof(ProjectTrackingCode),
            typeof(Registrar),
            typeof(TechnicalOption),
            typeof(TechnicalStatus),
            typeof(Theme),
            typeof(TrackingCode),
            typeof(Authentication),
            typeof(AuthenticationRole)
        };

        public static string ConnectionString
        {
            get
            {
                var cnx = MSSqlConnectionProvider.GetConnectionString("51.178.78.164", "BWH_API_User", "Tstr%20SFRq.ptg", "BWH");
                return cnx;
            }
        }

        public static void Connect(bool threadSafe = true)
        {
            //Avoid setting dataLayer for plugin app to the default XPO property NOT to conflict default dataLayer call used in main/host application (i.e. Suadeo Designer)
            //XpoDefault.DataLayer = CreateDataLayer(threadSafe);
            appDataLayer = CreateDataLayer(threadSafe);
        }

        static IDataLayer CreateDataLayer(bool threadSafe)
        {
            string connStr = XpoDefault.GetConnectionPoolString(ConnectionString);
            ReflectionDictionary dictionary = new ReflectionDictionary();
            dictionary.GetDataStoreSchema(PersistentTypes);   // Pass all of your persistent object types to this method.
            AutoCreateOption autoCreateOption = AutoCreateOption.SchemaAlreadyExists;  // Use AutoCreateOption.DatabaseAndSchema if the database or tables do not exist. Use AutoCreateOption.SchemaAlreadyExists if the database already exists.
            IDataStore provider = XpoDefault.GetConnectionProvider(connStr, autoCreateOption);
            return threadSafe ? (IDataLayer)new ThreadSafeDataLayer(dictionary, provider) : new SimpleDataLayer(dictionary, provider);
        }
        public static UnitOfWork CreateUnitOfWork()
        {
            if (appDataLayer == null)
                Connect();

            return new UnitOfWork(appDataLayer);
        }

    }
}