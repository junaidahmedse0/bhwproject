using Microsoft.AspNetCore.Mvc;
using BWH_API.Service.IService;
using BWH_API.DTO;
using Microsoft.AspNetCore.Authorization;

namespace BWH_API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("[controller]")]
    public class RefController : ControllerBase
    {

        IAgeGroupService _ageGroupService { get; }
        IBusinessSectorService _businessSectorService { get; }
        ICategoryService _categoryService { get; }
        ICountryService _countryService { get; }
        IDateOptionService _dateOptionService { get; }
        IDomainNameService _domainNameService { get; }
        IEntityTypeService _entityTypeService { get; }
        IExpertiseAreaService _expertiseAreaService { get; }
        IGenderGroupService _genderGroupService { get; }
        IHostService _hostService { get; }
        ILanguageService _languageService { get; }
        IPeriodicityService _periodicityService { get; }
        IPersonService _personService { get; }
        IRegistrarService _registrarService { get; }
        ITechnicalOptionService _technicalOptionsService { get; }
        ITechnicalStatusService _technicalStatusService { get; }
        IThemeService _themeService { get; }



        public RefController()
        {
            _ageGroupService = new AgeGroupService();
            _businessSectorService = new BusinessSectorService();
            _categoryService = new CategoryService();
            _countryService = new CountryService();
            _dateOptionService = new DateOptionService();
            _domainNameService = new DomainNameService();
            _entityTypeService = new EntityTypeService();
            _domainNameService = new DomainNameService();
            _entityTypeService = new EntityTypeService();
            _expertiseAreaService = new ExpertiseAreaService();
            _genderGroupService = new GenderGroupService();
            _hostService = new HostService();
            _languageService = new LanguageService();
            _periodicityService = new PeriodicityService();
            _personService = new PersonService();
            _registrarService = new RegistrarService();
            _technicalOptionsService = new TechnicalOptionService();
            _technicalStatusService = new TechnicalStatusService();
            _themeService = new ThemeService();


        }

        //GET

        [HttpGet]
        [Route("GetAllCategory")]
        async public Task<List<CategoryDTO>> GetAllCategory()
        {
            return await _categoryService.GetAllCategoryAsync("");
        }

        [HttpGet]
        [Route("GetAllAgeGroup")]
        async public Task<List<AgeGroupDTO>> GetAllAgeGroup()
        {
            return await _ageGroupService.GetAllAgeGroupAsync("");
        }

        [HttpGet]
        [Route("GetAllBusinessSector")]
        async public Task<List<BusinessSectorDTO>> GetAllBusinessSector()
        {
            return await _businessSectorService.GetAllBusinessSectorAsync("");

        }

        [HttpGet]
        [Route("GetAllCountry")]
        async public Task<List<CountryDTO>> GetAllCountry()
        {
            return await _countryService.GetAllCountryAsync("");

        }

        [HttpGet]
        [Route("GetAllDateOption")]
        async public Task<List<DateOptionDTO>> GetAllDateOption()
        {
            return await _dateOptionService.GetAllDateOptionAsync("");

        }

        [HttpGet]
        [Route("GetAllDomainName")]
        async public Task<List<DomainNameDTO>> GetAllDomainName()
        {
            return await _domainNameService.GetAllDomainNameAsync("");

        }

        [HttpGet]
        [Route("GetAllEntityType")]
        async public Task<List<EntityTypeDTO>> GetAllEntityType()
        {
            return await _entityTypeService.GetAllEntityTypeAsync("");

        }

        [HttpGet]
        [Route("GetAllExpertiseArea")]
        async public Task<List<ExpertiseAreaDTO>> GetAllExpertiseArea()
        {
            return await _expertiseAreaService.GetAllExpertiseAreaAsync("");

        }

        [HttpGet]
        [Route("GetAllGenderGroup")]
        async public Task<List<GenderGroupDTO>> GetAllGenderGroup()
        {
            return await _genderGroupService.GetAllGenderGroupAsync("");
        }

        [HttpGet]
        [Route("GetAllHost")]
        async public Task<List<HostDTO>> GetAllHost()
        {
            return await _hostService.GetAllHostAsync("");
        }

        [HttpGet]
        [Route("GetAllLanguage")]
        async public Task<List<LanguageDTO>> GetAllLanguage()
        {
            return await _languageService.GetAllLanguageAsync("");
        }

        [HttpGet]
        [Route("GetAllPeriodicity")]
        async public Task<List<PeriodicityDTO>> GetAllPeriodicity()
        {
            return await _periodicityService.GetAllPeriodicityAsync("");
        }

        [HttpGet]
        [Route("GetAllPerson")]
        async public Task<List<PersonDTO>> GetAllPerson()
        {
            return await _personService.GetAllPersonAsync("");
        }

        [HttpGet]
        [Route("GetAllRegistrar")]
        async public Task<List<RegistrarDTO>> GetAllRegistrar()
        {
            return await _registrarService.GetAllRegistrarAsync("");
        }

        [HttpGet]
        [Route("GetAllTechnicalOption")]
        async public Task<List<TechnicalOptionDTO>> GetAllTechnicalOption()
        {
            return await _technicalOptionsService.GetAllTechnicalOptionAsync("");
        }

        [HttpGet]
        [Route("GetAllTechnicalStatus")]
        async public Task<List<TechnicalStatusDTO>> GetAllTechnicalStatus()
        {
            return await _technicalStatusService.GetAllTechnicalStatusAsync("");
        }





        //ADD


        [HttpPost]
        [Route("AddCategory")]
        public async Task<ActionResult> CreateCategoryAsync([FromBody] CategoryDTO postData)
        {
            int insertId = await _categoryService.CreateCategoryAsync(postData, "");
            return Ok(insertId);
        }



        [HttpPost(Name = "AddWeather")]
        public async Task<ActionResult> AddWeather(int OrderId)
        {
            return Ok();
        }


        //[HttpGet(Name = "GetCategoryController2")]
        //public IEnumerable<WeatherForecast> Get2()
        //{
        //    return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        //    {
        //        Date = DateTime.Now.AddDays(index),
        //        TemperatureC = Random.Shared.Next(-20, 55),
        //        Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        //    })
        //    .ToArray();
        //}
    }
}