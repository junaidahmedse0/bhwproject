﻿using BWH_API.DTO;
using BWH_API.Services;
using BWH_API.Services.IServices;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BWH_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        public IAccountService _accountService { get; set; }
        public AccountController()
        { 
            _accountService = new AccountService();
        }
        [HttpPost]
        [Route("register")]
        public async Task<IActionResult> Register(AuthenticationDto _userData)
        {
            await _accountService.Register(_userData);
            return Ok();
        }
        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login(AuthenticationDto _userData)
        {
            if (_userData != null && _userData.Login != null && _userData.Password != null)
            {
                var user = await _accountService.Login(_userData);

                if (user != null)
                {
                    return Ok(user);
                }
                else
                {
                    return BadRequest(new { status = "invalid", message = "Invalid Credentials" });
                }
            }
            else
            {
                return BadRequest();
            }
       
        }
    }
}
