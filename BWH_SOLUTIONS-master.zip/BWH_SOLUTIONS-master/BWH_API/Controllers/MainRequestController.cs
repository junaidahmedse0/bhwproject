﻿using Microsoft.AspNetCore.Mvc;
using BWH_API.Service.IService;
using BWH_API.DTO;
using Microsoft.AspNetCore.Authorization;

namespace BWH_API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("[controller]")]
    public class MainRequestController : ControllerBase
    {
        IMainRequestService _mainrequestService { get; }
        public MainRequestController()
        {
            _mainrequestService = new MainRequestService();
        }
        //GET
        [HttpGet]
        [Route("GetAllMainRequest")]
        async public Task<List<MainRequestDTO>> GetAllMainRequest()
        {
            return await _mainrequestService.GetAllMainRequestAsync("");
        }
        //ADD
        [HttpPost]
        [Route("AddMainRequest")]
        public async Task<ActionResult> AddMainRequestAsync([FromBody] MainRequestDTO postData)
        {
            int insertId = await _mainrequestService.CreateMainRequestAsync(postData, "");
            return Ok(insertId);
        }
        //UPDATE
        [HttpPost]
        [Route("UpdateMainRequest")]
        public async Task<ActionResult> UpdateMainRequestAsync([FromBody] MainRequestDTO postData)
        {
            await _mainrequestService.UpdateMainRequestAsync(postData, "");
            return Ok();
        }
        //DELETE
        [HttpPost]
        [Route("DeleteMainRequest")]
        public async Task<ActionResult> DeleteMainRequestAsync([FromBody] MainRequestDTO postData)
        {
            await _mainrequestService.DeleteMainRequestAsync(postData, "");
            return Ok();
        }
    }
}
