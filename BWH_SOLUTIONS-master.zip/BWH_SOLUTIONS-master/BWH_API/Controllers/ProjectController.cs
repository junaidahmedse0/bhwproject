﻿using Microsoft.AspNetCore.Mvc;
using BWH_API.Service.IService;
using BWH_API.DTO;
using Microsoft.AspNetCore.Authorization;
using static BWH_API.Repository.AccountRepository;

namespace BWH_API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("[controller]")]
    public class ProjectController : ControllerBase
    {

        IProjectService _projectService { get; }




        public ProjectController()
        {
            _projectService = new ProjectService();



        }

        //GET
        [HttpGet]
        [Route("GetAllProject")]
        async public Task<List<ProjectDTO>> GetAllProject()
        {
            return await _projectService.GetAllProjectAsync("");
        }



        //ADD
        [HttpPost]
        [Route("AddProject")]
        public async Task<ActionResult> AddProjectAsync([FromBody] ProjectDTO postData)
        {
            int insertId = await _projectService.CreateProjectAsync(postData, "");
            return Ok(insertId);
        }

        //UPDATE
        [HttpPost]
        [Route("UpdateProject")]
        public async Task<ActionResult> UpdateProjectAsync([FromBody] ProjectDTO postData)
        {
            await _projectService.UpdateProjectAsync(postData, "");
            return Ok();

        }

        //DELETE
        [HttpPost]
        [Route("DeleteProject")]
        public async Task<ActionResult> DeleteProjectAsync([FromBody] ProjectDTO postData)
        {
            await _projectService.DeleteProjectAsync(postData, "");
            return Ok();

        }



    }
}