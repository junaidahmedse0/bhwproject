using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.Host")]
public class Host : XPLiteObject
{
public Host(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fHostId;
[Key(true), Persistent("HostId")]
public int HostId
{
get { return fHostId; }
set { SetPropertyValue<int>(nameof(HostId), ref fHostId, value); }
}
int fCountryId;
[Persistent("CountryId")]
public int CountryId
{
get { return fCountryId; }
set { SetPropertyValue<int>(nameof(CountryId), ref fCountryId, value); }
}
string fHostName;
[Persistent("HostName")]
public string HostName
{
get { return fHostName; }
set { SetPropertyValue<string>(nameof(HostName), ref fHostName, value); }
}
string fHostUrl;
[Persistent("HostUrl")]
public string HostUrl
{
get { return fHostUrl; }
set { SetPropertyValue<string>(nameof(HostUrl), ref fHostUrl, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
