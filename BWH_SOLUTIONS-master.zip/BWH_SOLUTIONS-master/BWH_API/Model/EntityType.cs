using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.EntityType")]
public class EntityType : XPLiteObject
{
public EntityType(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fEntityTypeId;
[Key(true), Persistent("EntityTypeId")]
public int EntityTypeId
{
get { return fEntityTypeId; }
set { SetPropertyValue<int>(nameof(EntityTypeId), ref fEntityTypeId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
