using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
    [Persistent("dbo.Project")]
    public class Project : XPLiteObject
    {
        public Project(Session session) : base(session)
        {
            // This constructor is used when an object is loaded from a persistent storage.
            // Do not place any code here.
        }
        int fProjectId;
        [Key(true), Persistent("ProjectId")]
        public int ProjectId
        {
            get { return fProjectId; }
            set { SetPropertyValue<int>(nameof(ProjectId), ref fProjectId, value); }
        }
        int fCategoryId;
        [Persistent("CategoryId")]
        public int CategoryId
        {
            get { return fCategoryId; }
            set { SetPropertyValue<int>(nameof(CategoryId), ref fCategoryId, value); }
        }
        int fBusinessSectorId;
        [Persistent("BusinessSectorId")]
        public int BusinessSectorId
        {
            get { return fBusinessSectorId; }
            set { SetPropertyValue<int>(nameof(BusinessSectorId), ref fBusinessSectorId, value); }
        }
        int fThemeId;
        [Persistent("ThemeId")]
        public int ThemeId
        {
            get { return fThemeId; }
            set { SetPropertyValue<int>(nameof(ThemeId), ref fThemeId, value); }
        }
        int fTechnicalStatusId;
        [Persistent("TechnicalStatusId")]
        public int TechnicalStatusId
        {
            get { return fTechnicalStatusId; }
            set { SetPropertyValue<int>(nameof(TechnicalStatusId), ref fTechnicalStatusId, value); }
        }
        int fLanguageId;
        [Persistent("LanguageId")]
        public int LanguageId
        {
            get { return fLanguageId; }
            set { SetPropertyValue<int>(nameof(LanguageId), ref fLanguageId, value); }
        }
        int fAgeGroupId;
        [Persistent("AgeGroupId")]
        public int AgeGroupId
        {
            get { return fAgeGroupId; }
            set { SetPropertyValue<int>(nameof(AgeGroupId), ref fAgeGroupId, value); }
        }
        int fGenderGroupId;
        [Persistent("GenderGroupId")]
        public int GenderGroupId
        {
            get { return fGenderGroupId; }
            set { SetPropertyValue<int>(nameof(GenderGroupId), ref fGenderGroupId, value); }
        }
        int fHostId;
        [Persistent("HostId")]
        public int HostId
        {
            get { return fHostId; }
            set { SetPropertyValue<int>(nameof(HostId), ref fHostId, value); }
        }
        int fDomainNameId;
        [Persistent("DomainNameId")]
        public int DomainNameId
        {
            get { return fDomainNameId; }
            set { SetPropertyValue<int>(nameof(DomainNameId), ref fDomainNameId, value); }
        }
        string fCode;
        [Persistent("Code")]
        public string Code
        {
            get { return fCode; }
            set { SetPropertyValue<string>(nameof(Code), ref fCode, value); }
        }
        string fTitle;
        [Persistent("Title")]
        public string Title
        {
            get { return fTitle; }
            set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
        }
        string fDescription;
        [Persistent("Description")]
        public string Description
        {
            get { return fDescription; }
            set { SetPropertyValue<string>(nameof(Description), ref fDescription, value); }
        }
        string fFolder;
        [Persistent("Folder")]
        public string Folder
        {
            get { return fFolder; }
            set { SetPropertyValue<string>(nameof(Folder), ref fFolder, value); }
        }
        DateTime fDateCreated;
        [Persistent("DateCreated")]
        public DateTime DateCreated
        {
            get { return fDateCreated; }
            set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
        }
        DateTime fDateUpdated;
        [Persistent("DateUpdated")]
        public DateTime DateUpdated
        {
            get { return fDateUpdated; }
            set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
        }
    }
}
