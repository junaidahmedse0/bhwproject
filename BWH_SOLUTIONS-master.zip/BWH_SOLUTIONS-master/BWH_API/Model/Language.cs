using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.Language")]
public class Language : XPLiteObject
{
public Language(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fLanguageId;
[Key(true), Persistent("LanguageId")]
public int LanguageId
{
get { return fLanguageId; }
set { SetPropertyValue<int>(nameof(LanguageId), ref fLanguageId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
string fCode;
[Persistent("Code")]
public string Code
{
get { return fCode; }
set { SetPropertyValue<string>(nameof(Code), ref fCode, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
