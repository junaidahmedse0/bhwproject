using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.DomainName")]
public class DomainName : XPLiteObject
{
public DomainName(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fDomainNameId;
[Key(true), Persistent("DomainNameId")]
public int DomainNameId
{
get { return fDomainNameId; }
set { SetPropertyValue<int>(nameof(DomainNameId), ref fDomainNameId, value); }
}
int fRegistrarId;
[Persistent("RegistrarId")]
public int RegistrarId
{
get { return fRegistrarId; }
set { SetPropertyValue<int>(nameof(RegistrarId), ref fRegistrarId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
string fSubscriptionStartingDate;
[Persistent("SubscriptionStartingDate")]
public string SubscriptionStartingDate
{
get { return fSubscriptionStartingDate; }
set { SetPropertyValue<string>(nameof(SubscriptionStartingDate), ref fSubscriptionStartingDate, value); }
}
string fNextRenewalDate;
[Persistent("NextRenewalDate")]
public string NextRenewalDate
{
get { return fNextRenewalDate; }
set { SetPropertyValue<string>(nameof(NextRenewalDate), ref fNextRenewalDate, value); }
}
string fPrice;
[Persistent("Price")]
public string Price
{
get { return fPrice; }
set { SetPropertyValue<string>(nameof(Price), ref fPrice, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
int fTechnicalStatusId;
[Persistent("TechnicalStatusId")]
public int TechnicalStatusId
{
get { return fTechnicalStatusId; }
set { SetPropertyValue<int>(nameof(TechnicalStatusId), ref fTechnicalStatusId, value); }
}
}}
