using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("dbo.EntityTechnicalOption")]
public class EntityTechnicalOption : XPLiteObject
{
public EntityTechnicalOption(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fEntityTechnicalOptionId;
[Key(true), Persistent("EntityTechnicalOptionId")]
public int EntityTechnicalOptionId
{
get { return fEntityTechnicalOptionId; }
set { SetPropertyValue<int>(nameof(EntityTechnicalOptionId), ref fEntityTechnicalOptionId, value); }
}
int fEntityId;
[Persistent("EntityId")]
public int EntityId
{
get { return fEntityId; }
set { SetPropertyValue<int>(nameof(EntityId), ref fEntityId, value); }
}
int fTechnicalOptionId;
[Persistent("TechnicalOptionId")]
public int TechnicalOptionId
{
get { return fTechnicalOptionId; }
set { SetPropertyValue<int>(nameof(TechnicalOptionId), ref fTechnicalOptionId, value); }
}
string fTechnicalOptionValue;
[Persistent("TechnicalOptionValue")]
public string TechnicalOptionValue
{
get { return fTechnicalOptionValue; }
set { SetPropertyValue<string>(nameof(TechnicalOptionValue), ref fTechnicalOptionValue, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
