using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("dbo.TrackingCode")]
public class TrackingCode : XPLiteObject
{
public TrackingCode(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fTrackingCodeId;
[Key(true), Persistent("TrackingCodeId")]
public int TrackingCodeId
{
get { return fTrackingCodeId; }
set { SetPropertyValue<int>(nameof(TrackingCodeId), ref fTrackingCodeId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
string fTag;
[Persistent("Tag")]
public string Tag
{
get { return fTag; }
set { SetPropertyValue<string>(nameof(Tag), ref fTag, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
