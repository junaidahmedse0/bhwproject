using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("stg.AmazonFeeLinkType")]
public class AmazonFeeLinkType : XPLiteObject
{
public AmazonFeeLinkType(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fId;
[Key(true), Persistent("Id")]
public int Id
{
get { return fId; }
set { SetPropertyValue<int>(nameof(Id), ref fId, value); }
}
string fLinkType;
[Persistent("LinkType")]
public string LinkType
{
get { return fLinkType; }
set { SetPropertyValue<string>(nameof(LinkType), ref fLinkType, value); }
}
string fLinkCode;
[Persistent("LinkCode")]
public string LinkCode
{
get { return fLinkCode; }
set { SetPropertyValue<string>(nameof(LinkCode), ref fLinkCode, value); }
}
string fClicks;
[Persistent("Clicks")]
public string Clicks
{
get { return fClicks; }
set { SetPropertyValue<string>(nameof(Clicks), ref fClicks, value); }
}
string fProductOrdered;
[Persistent("ProductOrdered")]
public string ProductOrdered
{
get { return fProductOrdered; }
set { SetPropertyValue<string>(nameof(ProductOrdered), ref fProductOrdered, value); }
}
string fConversion;
[Persistent("Conversion")]
public string Conversion
{
get { return fConversion; }
set { SetPropertyValue<string>(nameof(Conversion), ref fConversion, value); }
}
string fProductOrderedAmount;
[Persistent("ProductOrderedAmount")]
public string ProductOrderedAmount
{
get { return fProductOrderedAmount; }
set { SetPropertyValue<string>(nameof(ProductOrderedAmount), ref fProductOrderedAmount, value); }
}
string fProductShipped;
[Persistent("ProductShipped")]
public string ProductShipped
{
get { return fProductShipped; }
set { SetPropertyValue<string>(nameof(ProductShipped), ref fProductShipped, value); }
}
string fEarnings;
[Persistent("Earnings")]
public string Earnings
{
get { return fEarnings; }
set { SetPropertyValue<string>(nameof(Earnings), ref fEarnings, value); }
}
}}
