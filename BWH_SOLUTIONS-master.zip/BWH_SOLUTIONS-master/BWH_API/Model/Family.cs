using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("dbo.Family")]
public class Family : XPLiteObject
{
public Family(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fFamilyId;
[Key(true), Persistent("FamilyId")]
public int FamilyId
{
get { return fFamilyId; }
set { SetPropertyValue<int>(nameof(FamilyId), ref fFamilyId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fUpdatedDate;
[Persistent("UpdatedDate")]
public DateTime UpdatedDate
{
get { return fUpdatedDate; }
set { SetPropertyValue<DateTime>(nameof(UpdatedDate), ref fUpdatedDate, value); }
}
}}
