using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("stg.AmazonFeeOrders")]
public class AmazonFeeOrders : XPLiteObject
{
public AmazonFeeOrders(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fId;
[Key(true), Persistent("Id")]
public int Id
{
get { return fId; }
set { SetPropertyValue<int>(nameof(Id), ref fId, value); }
}
string fCategory;
[Persistent("Category")]
public string Category
{
get { return fCategory; }
set { SetPropertyValue<string>(nameof(Category), ref fCategory, value); }
}
string fProduct;
[Persistent("Product")]
public string Product
{
get { return fProduct; }
set { SetPropertyValue<string>(nameof(Product), ref fProduct, value); }
}
string fAmazonStandardIdentificationNumber;
[Persistent("AmazonStandardIdentificationNumber")]
public string AmazonStandardIdentificationNumber
{
get { return fAmazonStandardIdentificationNumber; }
set { SetPropertyValue<string>(nameof(AmazonStandardIdentificationNumber), ref fAmazonStandardIdentificationNumber, value); }
}
string fOperationDate;
[Persistent("OperationDate")]
public string OperationDate
{
get { return fOperationDate; }
set { SetPropertyValue<string>(nameof(OperationDate), ref fOperationDate, value); }
}
string fQuantity;
[Persistent("Quantity")]
public string Quantity
{
get { return fQuantity; }
set { SetPropertyValue<string>(nameof(Quantity), ref fQuantity, value); }
}
string fPrice;
[Persistent("Price")]
public string Price
{
get { return fPrice; }
set { SetPropertyValue<string>(nameof(Price), ref fPrice, value); }
}
string fLinkType;
[Persistent("LinkType")]
public string LinkType
{
get { return fLinkType; }
set { SetPropertyValue<string>(nameof(LinkType), ref fLinkType, value); }
}
string fTag;
[Persistent("Tag")]
public string Tag
{
get { return fTag; }
set { SetPropertyValue<string>(nameof(Tag), ref fTag, value); }
}
string fLinkProductOrder;
[Persistent("LinkProductOrder")]
public string LinkProductOrder
{
get { return fLinkProductOrder; }
set { SetPropertyValue<string>(nameof(LinkProductOrder), ref fLinkProductOrder, value); }
}
string fDevice;
[Persistent("Device")]
public string Device
{
get { return fDevice; }
set { SetPropertyValue<string>(nameof(Device), ref fDevice, value); }
}
}}
