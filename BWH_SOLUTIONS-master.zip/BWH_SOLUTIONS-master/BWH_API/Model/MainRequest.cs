using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
    [Persistent("dbo.MainRequest")]
    public class MainRequest : XPLiteObject
    {
        public MainRequest(Session session) : base(session)
        {
            // This constructor is used when an object is loaded from a persistent storage.
            // Do not place any code here.
        }
        int fMainRequestId;
        [Key(true), Persistent("MainRequestId")]
        public int MainRequestId
        {
            get { return fMainRequestId; }
            set { SetPropertyValue<int>(nameof(MainRequestId), ref fMainRequestId, value); }
        }
        int fMainRequestParentId;
        [Persistent("MainRequestParentId")]
        public int MainRequestParentId
        {
            get { return fMainRequestParentId; }
            set { SetPropertyValue<int>(nameof(MainRequestParentId), ref fMainRequestParentId, value); }
        }
        int fLanguageId;
        [Persistent("LanguageId")]
        public int LanguageId
        {
            get { return fLanguageId; }
            set { SetPropertyValue<int>(nameof(LanguageId), ref fLanguageId, value); }
        }
        string fMainRequest;
        [Persistent("MainRequest")]
        public string MMainRequest
        {
            get { return fMainRequest; }
            set { SetPropertyValue<string>(nameof(MainRequest), ref fMainRequest, value); }
        }
        string fLexicalField1;
        [Persistent("LexicalField1")]
        public string LexicalField1
        {
            get { return fLexicalField1; }
            set { SetPropertyValue<string>(nameof(LexicalField1), ref fLexicalField1, value); }
        }
        string fLexicalField2;
        [Persistent("LexicalField2")]
        public string LexicalField2
        {
            get { return fLexicalField2; }
            set { SetPropertyValue<string>(nameof(LexicalField2), ref fLexicalField2, value); }
        }
        string fLexicalField3;
        [Persistent("LexicalField3")]
        public string LexicalField3
        {
            get { return fLexicalField3; }
            set { SetPropertyValue<string>(nameof(LexicalField3), ref fLexicalField3, value); }
        }
        string fLexicalField4;
        [Persistent("LexicalField4")]
        public string LexicalField4
        {
            get { return fLexicalField4; }
            set { SetPropertyValue<string>(nameof(LexicalField4), ref fLexicalField4, value); }
        }
        string fLexicalField5;
        [Persistent("LexicalField5")]
        public string LexicalField5
        {
            get { return fLexicalField5; }
            set { SetPropertyValue<string>(nameof(LexicalField5), ref fLexicalField5, value); }
        }
        string fLexicalField6;
        [Persistent("LexicalField6")]
        public string LexicalField6
        {
            get { return fLexicalField6; }
            set { SetPropertyValue<string>(nameof(LexicalField6), ref fLexicalField6, value); }
        }
        DateTime fDateCreated;
        [Persistent("DateCreated")]
        public DateTime DateCreated
        {
            get { return fDateCreated; }
            set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
        }
        DateTime fDateUpdated;
        [Persistent("DateUpdated")]
        public DateTime DateUpdated
        {
            get { return fDateUpdated; }
            set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
        }
    }
}
