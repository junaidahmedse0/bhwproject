﻿using DevExpress.Xpo;

namespace BWH_API.Model
{
    [Persistent("dbo.Authentication")]
    public class Authentication : XPLiteObject
    {
        public Authentication(Session session) : base(session) { }

        [Key(AutoGenerate = true), Persistent("AuthenticationId")]
        public int AuthenticationId { get; set; }

        [Persistent("Login")]
        public string Login { get; set; }

        [Persistent("Password")]
        public string Password { get; set; }

        [Persistent("AuthenticationRoleId")]
        public int AuthenticationRoleId { get; set; }
        [Persistent("DateCreated")]
        public DateTime DateCreated { get; set; }

        [Persistent("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }
    }

    [Persistent("dbo.AuthenticationRole")]
    public class AuthenticationRole : XPLiteObject
    {
        public AuthenticationRole(Session session) : base(session) { }

        [Key(AutoGenerate = true), Persistent("AuthenticationRoleId")]
        public int AuthenticationRoleId { get; set; }

        [Persistent("Title")]
        public string Title { get; set; }


        [Persistent("DateCreated")]
        public DateTime DateCreated { get; set; }

        [Persistent("UpdatedDate")]
        public DateTime UpdatedDate { get; set; }
    }
}
