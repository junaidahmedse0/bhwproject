using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("dbo.EntityDateOption")]
public class EntityDateOption : XPLiteObject
{
public EntityDateOption(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fEntityDateOptionId;
[Key(true), Persistent("EntityDateOptionId")]
public int EntityDateOptionId
{
get { return fEntityDateOptionId; }
set { SetPropertyValue<int>(nameof(EntityDateOptionId), ref fEntityDateOptionId, value); }
}
int fEntityId;
[Persistent("EntityId")]
public int EntityId
{
get { return fEntityId; }
set { SetPropertyValue<int>(nameof(EntityId), ref fEntityId, value); }
}
int fDateOptionId;
[Persistent("DateOptionId")]
public int DateOptionId
{
get { return fDateOptionId; }
set { SetPropertyValue<int>(nameof(DateOptionId), ref fDateOptionId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
string fStartingDate;
[Persistent("StartingDate")]
public string StartingDate
{
get { return fStartingDate; }
set { SetPropertyValue<string>(nameof(StartingDate), ref fStartingDate, value); }
}
string fEndingDate;
[Persistent("EndingDate")]
public string EndingDate
{
get { return fEndingDate; }
set { SetPropertyValue<string>(nameof(EndingDate), ref fEndingDate, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
