using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.Country")]
public class Country : XPLiteObject
{
public Country(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fCountryId;
[Key(true), Persistent("CountryId")]
public int CountryId
{
get { return fCountryId; }
set { SetPropertyValue<int>(nameof(CountryId), ref fCountryId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
string fShortCode;
[Persistent("ShortCode")]
public string ShortCode
{
get { return fShortCode; }
set { SetPropertyValue<string>(nameof(ShortCode), ref fShortCode, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
