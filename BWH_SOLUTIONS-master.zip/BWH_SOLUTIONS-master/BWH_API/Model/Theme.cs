using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.Theme")]
public class Theme : XPLiteObject
{
public Theme(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fThemeId;
[Key(true), Persistent("ThemeId")]
public int ThemeId
{
get { return fThemeId; }
set { SetPropertyValue<int>(nameof(ThemeId), ref fThemeId, value); }
}
int fTechnicalStatusId;
[Persistent("TechnicalStatusId")]
public int TechnicalStatusId
{
get { return fTechnicalStatusId; }
set { SetPropertyValue<int>(nameof(TechnicalStatusId), ref fTechnicalStatusId, value); }
}
int fCreatorId;
[Persistent("CreatorId")]
public int CreatorId
{
get { return fCreatorId; }
set { SetPropertyValue<int>(nameof(CreatorId), ref fCreatorId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
