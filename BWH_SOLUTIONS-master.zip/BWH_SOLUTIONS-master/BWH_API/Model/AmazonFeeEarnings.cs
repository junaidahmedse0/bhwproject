using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("stg.AmazonFeeEarnings")]
public class AmazonFeeEarnings : XPLiteObject
{
public AmazonFeeEarnings(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fId;
[Key(true), Persistent("Id")]
public int Id
{
get { return fId; }
set { SetPropertyValue<int>(nameof(Id), ref fId, value); }
}
string fCategory;
[Persistent("Category")]
public string Category
{
get { return fCategory; }
set { SetPropertyValue<string>(nameof(Category), ref fCategory, value); }
}
string fProduct;
[Persistent("Product")]
public string Product
{
get { return fProduct; }
set { SetPropertyValue<string>(nameof(Product), ref fProduct, value); }
}
string fAmazonStandardIdentificationNumber;
[Persistent("AmazonStandardIdentificationNumber")]
public string AmazonStandardIdentificationNumber
{
get { return fAmazonStandardIdentificationNumber; }
set { SetPropertyValue<string>(nameof(AmazonStandardIdentificationNumber), ref fAmazonStandardIdentificationNumber, value); }
}
string fSeller;
[Persistent("Seller")]
public string Seller
{
get { return fSeller; }
set { SetPropertyValue<string>(nameof(Seller), ref fSeller, value); }
}
string fTrackingId;
[Persistent("TrackingId")]
public string TrackingId
{
get { return fTrackingId; }
set { SetPropertyValue<string>(nameof(TrackingId), ref fTrackingId, value); }
}
string fShippingDate;
[Persistent("ShippingDate")]
public string ShippingDate
{
get { return fShippingDate; }
set { SetPropertyValue<string>(nameof(ShippingDate), ref fShippingDate, value); }
}
string fPrice;
[Persistent("Price")]
public string Price
{
get { return fPrice; }
set { SetPropertyValue<string>(nameof(Price), ref fPrice, value); }
}
string fProductShipped;
[Persistent("ProductShipped")]
public string ProductShipped
{
get { return fProductShipped; }
set { SetPropertyValue<string>(nameof(ProductShipped), ref fProductShipped, value); }
}
string fProductReturned;
[Persistent("ProductReturned")]
public string ProductReturned
{
get { return fProductReturned; }
set { SetPropertyValue<string>(nameof(ProductReturned), ref fProductReturned, value); }
}
string fRevenue;
[Persistent("Revenue")]
public string Revenue
{
get { return fRevenue; }
set { SetPropertyValue<string>(nameof(Revenue), ref fRevenue, value); }
}
string fAdvertisingFee;
[Persistent("AdvertisingFee")]
public string AdvertisingFee
{
get { return fAdvertisingFee; }
set { SetPropertyValue<string>(nameof(AdvertisingFee), ref fAdvertisingFee, value); }
}
string fDevice;
[Persistent("Device")]
public string Device
{
get { return fDevice; }
set { SetPropertyValue<string>(nameof(Device), ref fDevice, value); }
}
string fDirect;
[Persistent("Direct")]
public string Direct
{
get { return fDirect; }
set { SetPropertyValue<string>(nameof(Direct), ref fDirect, value); }
}
}}
