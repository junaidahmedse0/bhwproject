using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.Periodicity")]
public class Periodicity : XPLiteObject
{
public Periodicity(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fPeriodicityId;
[Key(true), Persistent("PeriodicityId")]
public int PeriodicityId
{
get { return fPeriodicityId; }
set { SetPropertyValue<int>(nameof(PeriodicityId), ref fPeriodicityId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
