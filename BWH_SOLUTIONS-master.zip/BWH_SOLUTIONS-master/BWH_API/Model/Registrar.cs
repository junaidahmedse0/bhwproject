using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.Registrar")]
public class Registrar : XPLiteObject
{
public Registrar(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fRegistrarId;
[Key(true), Persistent("RegistrarId")]
public int RegistrarId
{
get { return fRegistrarId; }
set { SetPropertyValue<int>(nameof(RegistrarId), ref fRegistrarId, value); }
}
string fName;
[Persistent("Name")]
public string Name
{
get { return fName; }
set { SetPropertyValue<string>(nameof(Name), ref fName, value); }
}
string fUrl;
[Persistent("Url")]
public string Url
{
get { return fUrl; }
set { SetPropertyValue<string>(nameof(Url), ref fUrl, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
