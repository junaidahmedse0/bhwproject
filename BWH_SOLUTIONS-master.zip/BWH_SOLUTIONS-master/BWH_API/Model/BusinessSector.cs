using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.BusinessSector")]
public class BusinessSector : XPLiteObject
{
public BusinessSector(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fBusinessSectorId;
[Key(true), Persistent("BusinessSectorId")]
public int BusinessSectorId
{
get { return fBusinessSectorId; }
set { SetPropertyValue<int>(nameof(BusinessSectorId), ref fBusinessSectorId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
