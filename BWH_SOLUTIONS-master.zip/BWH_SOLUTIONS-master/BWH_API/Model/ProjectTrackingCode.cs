using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("dbo.ProjectTrackingCode")]
public class ProjectTrackingCode : XPLiteObject
{
public ProjectTrackingCode(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fProjectTrackingCodeId;
[Key(true), Persistent("ProjectTrackingCodeId")]
public int ProjectTrackingCodeId
{
get { return fProjectTrackingCodeId; }
set { SetPropertyValue<int>(nameof(ProjectTrackingCodeId), ref fProjectTrackingCodeId, value); }
}
int fTrackingCodeId;
[Persistent("TrackingCodeId")]
public int TrackingCodeId
{
get { return fTrackingCodeId; }
set { SetPropertyValue<int>(nameof(TrackingCodeId), ref fTrackingCodeId, value); }
}
int fProjectId;
[Persistent("ProjectId")]
public int ProjectId
{
get { return fProjectId; }
set { SetPropertyValue<int>(nameof(ProjectId), ref fProjectId, value); }
}
string fCode;
[Persistent("Code")]
public string Code
{
get { return fCode; }
set { SetPropertyValue<string>(nameof(Code), ref fCode, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
