using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("ref.Person")]
public class Person : XPLiteObject
{
public Person(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fPersonId;
[Key(true), Persistent("PersonId")]
public int PersonId
{
get { return fPersonId; }
set { SetPropertyValue<int>(nameof(PersonId), ref fPersonId, value); }
}
int fExpertiseAreaId;
[Persistent("ExpertiseAreaId")]
public int ExpertiseAreaId
{
get { return fExpertiseAreaId; }
set { SetPropertyValue<int>(nameof(ExpertiseAreaId), ref fExpertiseAreaId, value); }
}
int fAdditionalExpertiseAreaId;
[Persistent("AdditionalExpertiseAreaId")]
public int AdditionalExpertiseAreaId
{
get { return fAdditionalExpertiseAreaId; }
set { SetPropertyValue<int>(nameof(AdditionalExpertiseAreaId), ref fAdditionalExpertiseAreaId, value); }
}
string fName;
[Persistent("Name")]
public string Name
{
get { return fName; }
set { SetPropertyValue<string>(nameof(Name), ref fName, value); }
}
string fMail;
[Persistent("Mail")]
public string Mail
{
get { return fMail; }
set { SetPropertyValue<string>(nameof(Mail), ref fMail, value); }
}
string fInfo;
[Persistent("Info")]
public string Info
{
get { return fInfo; }
set { SetPropertyValue<string>(nameof(Info), ref fInfo, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fDateUpdated;
[Persistent("DateUpdated")]
public DateTime DateUpdated
{
get { return fDateUpdated; }
set { SetPropertyValue<DateTime>(nameof(DateUpdated), ref fDateUpdated, value); }
}
}}
