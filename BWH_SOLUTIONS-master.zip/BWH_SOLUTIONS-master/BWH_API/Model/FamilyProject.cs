using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("dbo.FamilyProject")]
public class FamilyProject : XPLiteObject
{
public FamilyProject(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
int fFamilyProjectId;
[Key(true), Persistent("FamilyProjectId")]
public int FamilyProjectId
{
get { return fFamilyProjectId; }
set { SetPropertyValue<int>(nameof(FamilyProjectId), ref fFamilyProjectId, value); }
}
int fFamilyId;
[Persistent("FamilyId")]
public int FamilyId
{
get { return fFamilyId; }
set { SetPropertyValue<int>(nameof(FamilyId), ref fFamilyId, value); }
}
int fProjectId;
[Persistent("ProjectId")]
public int ProjectId
{
get { return fProjectId; }
set { SetPropertyValue<int>(nameof(ProjectId), ref fProjectId, value); }
}
string fTitle;
[Persistent("Title")]
public string Title
{
get { return fTitle; }
set { SetPropertyValue<string>(nameof(Title), ref fTitle, value); }
}
DateTime fDateCreated;
[Persistent("DateCreated")]
public DateTime DateCreated
{
get { return fDateCreated; }
set { SetPropertyValue<DateTime>(nameof(DateCreated), ref fDateCreated, value); }
}
DateTime fUpdatedDate;
[Persistent("UpdatedDate")]
public DateTime UpdatedDate
{
get { return fUpdatedDate; }
set { SetPropertyValue<DateTime>(nameof(UpdatedDate), ref fUpdatedDate, value); }
}
}}
