using System;
using DevExpress.Xpo;
namespace BWH_API.Model
{
[Persistent("dbo.sysdiagrams")]
public class sysdiagrams : XPLiteObject
{
public sysdiagrams(Session session) : base(session)
{
// This constructor is used when an object is loaded from a persistent storage.
// Do not place any code here.
}
string fname;
[Persistent("name")]
public string name
{
get { return fname; }
set { SetPropertyValue<string>(nameof(name), ref fname, value); }
}
int fprincipal_id;
[Persistent("principal_id")]
public int principal_id
{
get { return fprincipal_id; }
set { SetPropertyValue<int>(nameof(principal_id), ref fprincipal_id, value); }
}
int fdiagram_id;
[Key(true), Persistent("diagram_id")]
public int diagram_id
{
get { return fdiagram_id; }
set { SetPropertyValue<int>(nameof(diagram_id), ref fdiagram_id, value); }
}
int fversion;
[Persistent("version")]
public int version
{
get { return fversion; }
set { SetPropertyValue<int>(nameof(version), ref fversion, value); }
}
string fdefinition;
[Persistent("definition")]
public string definition
{
get { return fdefinition; }
set { SetPropertyValue<string>(nameof(definition), ref fdefinition, value); }
}
}}
