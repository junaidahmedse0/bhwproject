﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BWH_API
{
    public static class Constants
    {



        public const string APP_SCRIPT_VERSION = "1.0"; // Upon new release update this value to force client side script cache
        public const string PLUGIN_APP_CODE = "GestionSlam";
        public const string PLUGIN_API_ROUTE_PREFIX = "api/bwh";
        public static string BASE_URI =  "/api";

        //Host API URLs
        public const string HOST_API_LOGGER_URL = "/logger";
        public const string HOST_API_AUDIT_URL = "/audit";
        public const string HOST_API_CONNECTION_STRING_URL = "/apps/get/" + PLUGIN_APP_CODE + "/connectionString";

    }
}