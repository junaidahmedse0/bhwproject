﻿using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using System.Web;
using static BWH_API.Enums.Enums;
using BWH_API.Utility;
using BWH_API.Service.IService;

namespace BWH_API.Service
{
    public class LogService : ILogService
    {

        private IHttpClientService _httpClientService;

        public LogService()
        {
            _httpClientService = new HttpClientService();
        }

        #region Logger

        public async Task AddLogAsync<T>(string authCookie
            , BWH_API.Enums.Enums.LogLevel? logLevel = BWH_API.Enums.Enums.LogLevel.Info
            , string message = ""
            , string stackTrace = ""
            , string methodName = ""
            , DateTime? timestamp = null
            , long? userId = null)
        {
            try
            {

                var loggerPayload = new
                {
                    Type = logLevel.ToString(),
                    Message = LogHelper.GetLoggerMessage<T>(message, methodName),
                    StackTrace = stackTrace
                };

                await _httpClientService.SendPostAsync(authCookie, Constants.HOST_API_LOGGER_URL, JsonConvert.SerializeObject(loggerPayload));
            }
            catch (Exception)
            {
                //We only log to debug text file in here to avoid a log call infinite loop
            }
        }


        public async Task AddLogAsync<T>(string authCookie
           , BWH_API.Enums.Enums.LogLevel? logLevel = BWH_API.Enums.Enums.LogLevel.Info
           , Exception exception = null
           , string methodName = ""
           , DateTime? timestamp = null
           , long? userId = null)
        {
            await this.AddLogAsync<T>(authCookie
                , logLevel
                , (exception != null ? exception.Message : " ")
                , (exception != null ? exception.StackTrace : " ")
                , methodName
                , timestamp
                , userId);
        }

        #endregion Logger


        #region Audit
        public async Task AddAuditAsync<T>(string authCookie, string action)
        {
            await AddAuditAsync(authCookie, typeof(T).FullName, action);
        }


        public async Task AddAuditAsync(string authCookie, string controllerName, string action)
        {
            try
            {

                var auditPayload = new
                {
                    AppCode = Constants.PLUGIN_APP_CODE,
                    ControllerName = controllerName,
                    Action = action
                };

                await _httpClientService.SendPostAsync(authCookie, Constants.HOST_API_AUDIT_URL, JsonConvert.SerializeObject(auditPayload));
            }
            catch (Exception ex)
            {
                _ = this.AddLogAsync<LogService>(authCookie, logLevel: Enums.Enums.LogLevel.Error
                           , exception: ex
                           , methodName: "AddAuditAsync");
            }

        }

        #endregion Audit

    }
}