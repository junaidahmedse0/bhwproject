using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class GenderGroupService : IGenderGroupService
{
private IGenderGroupRepository _genderGroupRepository { get; }
 public GenderGroupService()
{
_genderGroupRepository = new GenderGroupRepository();
}
async public Task<List<GenderGroupDTO>> GetAllGenderGroupAsync(string authCookie)
{
try
{
return await _genderGroupRepository.GetAllGenderGroupAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateGenderGroupAsync(GenderGroupDTO genderGroupDTO, string authCookie)
{
try
{
int insertId = await _genderGroupRepository.CreateGenderGroupAsync(genderGroupDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateGenderGroupAsync(GenderGroupDTO genderGroupDTO, string authCookie)
{
try
{
await _genderGroupRepository.UpdateGenderGroupAsync(genderGroupDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteGenderGroupAsync(GenderGroupDTO genderGroupDTO, string authCookie)
{
try
{
await _genderGroupRepository.DeleteGenderGroupAsync(genderGroupDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
