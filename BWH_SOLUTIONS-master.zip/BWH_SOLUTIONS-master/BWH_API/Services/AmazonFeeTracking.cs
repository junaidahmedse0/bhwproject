using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class AmazonFeeTrackingService : IAmazonFeeTrackingService
{
private IAmazonFeeTrackingRepository _amazonFeeTrackingRepository { get; }
 public AmazonFeeTrackingService()
{
_amazonFeeTrackingRepository = new AmazonFeeTrackingRepository();
}
async public Task<List<AmazonFeeTrackingDTO>> GetAllAmazonFeeTrackingAsync(string authCookie)
{
try
{
return await _amazonFeeTrackingRepository.GetAllAmazonFeeTrackingAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonFeeTrackingDTO, string authCookie)
{
try
{
int insertId = await _amazonFeeTrackingRepository.CreateAmazonFeeTrackingAsync(amazonFeeTrackingDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonFeeTrackingDTO, string authCookie)
{
try
{
await _amazonFeeTrackingRepository.UpdateAmazonFeeTrackingAsync(amazonFeeTrackingDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonFeeTrackingDTO, string authCookie)
{
try
{
await _amazonFeeTrackingRepository.DeleteAmazonFeeTrackingAsync(amazonFeeTrackingDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
