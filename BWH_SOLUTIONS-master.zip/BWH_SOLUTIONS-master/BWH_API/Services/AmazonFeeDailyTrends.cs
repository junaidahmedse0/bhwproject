using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class AmazonFeeDailyTrendsService : IAmazonFeeDailyTrendsService
{
private IAmazonFeeDailyTrendsRepository _amazonFeeDailyTrendsRepository { get; }
 public AmazonFeeDailyTrendsService()
{
_amazonFeeDailyTrendsRepository = new AmazonFeeDailyTrendsRepository();
}
async public Task<List<AmazonFeeDailyTrendsDTO>> GetAllAmazonFeeDailyTrendsAsync(string authCookie)
{
try
{
return await _amazonFeeDailyTrendsRepository.GetAllAmazonFeeDailyTrendsAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonFeeDailyTrendsDTO, string authCookie)
{
try
{
int insertId = await _amazonFeeDailyTrendsRepository.CreateAmazonFeeDailyTrendsAsync(amazonFeeDailyTrendsDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonFeeDailyTrendsDTO, string authCookie)
{
try
{
await _amazonFeeDailyTrendsRepository.UpdateAmazonFeeDailyTrendsAsync(amazonFeeDailyTrendsDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonFeeDailyTrendsDTO, string authCookie)
{
try
{
await _amazonFeeDailyTrendsRepository.DeleteAmazonFeeDailyTrendsAsync(amazonFeeDailyTrendsDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
