using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class AmazonFeeEarningsService : IAmazonFeeEarningsService
{
private IAmazonFeeEarningsRepository _amazonFeeEarningsRepository { get; }
 public AmazonFeeEarningsService()
{
_amazonFeeEarningsRepository = new AmazonFeeEarningsRepository();
}
async public Task<List<AmazonFeeEarningsDTO>> GetAllAmazonFeeEarningsAsync(string authCookie)
{
try
{
return await _amazonFeeEarningsRepository.GetAllAmazonFeeEarningsAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonFeeEarningsDTO, string authCookie)
{
try
{
int insertId = await _amazonFeeEarningsRepository.CreateAmazonFeeEarningsAsync(amazonFeeEarningsDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonFeeEarningsDTO, string authCookie)
{
try
{
await _amazonFeeEarningsRepository.UpdateAmazonFeeEarningsAsync(amazonFeeEarningsDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonFeeEarningsDTO, string authCookie)
{
try
{
await _amazonFeeEarningsRepository.DeleteAmazonFeeEarningsAsync(amazonFeeEarningsDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
