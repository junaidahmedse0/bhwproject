using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class FamilyService : IFamilyService
{
private IFamilyRepository _familyRepository { get; }
 public FamilyService()
{
_familyRepository = new FamilyRepository();
}
async public Task<List<FamilyDTO>> GetAllFamilyAsync(string authCookie)
{
try
{
return await _familyRepository.GetAllFamilyAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateFamilyAsync(FamilyDTO familyDTO, string authCookie)
{
try
{
int insertId = await _familyRepository.CreateFamilyAsync(familyDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateFamilyAsync(FamilyDTO familyDTO, string authCookie)
{
try
{
await _familyRepository.UpdateFamilyAsync(familyDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteFamilyAsync(FamilyDTO familyDTO, string authCookie)
{
try
{
await _familyRepository.DeleteFamilyAsync(familyDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
