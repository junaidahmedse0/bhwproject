using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IFamilyProjectService
{
Task<List<FamilyProjectDTO>> GetAllFamilyProjectAsync(string authCookie);
Task<int> CreateFamilyProjectAsync(FamilyProjectDTO familyprojectDTO, string authCookie);
Task UpdateFamilyProjectAsync(FamilyProjectDTO familyprojectDTO, string authCookie);
 Task DeleteFamilyProjectAsync(FamilyProjectDTO familyprojectDTO, string authCookie);
}}
