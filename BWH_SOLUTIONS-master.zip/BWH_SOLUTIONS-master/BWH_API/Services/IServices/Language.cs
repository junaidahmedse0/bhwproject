using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface ILanguageService
{
Task<List<LanguageDTO>> GetAllLanguageAsync(string authCookie);
Task<int> CreateLanguageAsync(LanguageDTO languageDTO, string authCookie);
Task UpdateLanguageAsync(LanguageDTO languageDTO, string authCookie);
 Task DeleteLanguageAsync(LanguageDTO languageDTO, string authCookie);
}}
