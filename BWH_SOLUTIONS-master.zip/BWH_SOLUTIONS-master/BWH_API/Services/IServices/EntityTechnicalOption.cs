using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IEntityTechnicalOptionService
{
Task<List<EntityTechnicalOptionDTO>> GetAllEntityTechnicalOptionAsync(string authCookie);
Task<int> CreateEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entitytechnicaloptionDTO, string authCookie);
Task UpdateEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entitytechnicaloptionDTO, string authCookie);
 Task DeleteEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entitytechnicaloptionDTO, string authCookie);
}}
