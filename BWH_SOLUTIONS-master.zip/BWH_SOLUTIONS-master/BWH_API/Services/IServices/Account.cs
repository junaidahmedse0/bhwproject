﻿using BWH_API.DTO;

namespace BWH_API.Services.IServices
{
    public interface IAccountService
    {
        Task<int> Register(AuthenticationDto authentication);
        Task<Object> Login(AuthenticationDto authentication);

    }
}
