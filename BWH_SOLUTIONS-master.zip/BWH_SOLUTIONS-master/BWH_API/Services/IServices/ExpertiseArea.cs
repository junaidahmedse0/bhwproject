using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IExpertiseAreaService
{
Task<List<ExpertiseAreaDTO>> GetAllExpertiseAreaAsync(string authCookie);
Task<int> CreateExpertiseAreaAsync(ExpertiseAreaDTO expertiseareaDTO, string authCookie);
Task UpdateExpertiseAreaAsync(ExpertiseAreaDTO expertiseareaDTO, string authCookie);
 Task DeleteExpertiseAreaAsync(ExpertiseAreaDTO expertiseareaDTO, string authCookie);
}}
