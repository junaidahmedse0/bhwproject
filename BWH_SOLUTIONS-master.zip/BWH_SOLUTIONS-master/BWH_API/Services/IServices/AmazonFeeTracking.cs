using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IAmazonFeeTrackingService
{
Task<List<AmazonFeeTrackingDTO>> GetAllAmazonFeeTrackingAsync(string authCookie);
Task<int> CreateAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonfeetrackingDTO, string authCookie);
Task UpdateAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonfeetrackingDTO, string authCookie);
 Task DeleteAmazonFeeTrackingAsync(AmazonFeeTrackingDTO amazonfeetrackingDTO, string authCookie);
}}
