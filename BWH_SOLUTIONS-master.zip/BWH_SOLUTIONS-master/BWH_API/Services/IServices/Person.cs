using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IPersonService
{
Task<List<PersonDTO>> GetAllPersonAsync(string authCookie);
Task<int> CreatePersonAsync(PersonDTO personDTO, string authCookie);
Task UpdatePersonAsync(PersonDTO personDTO, string authCookie);
 Task DeletePersonAsync(PersonDTO personDTO, string authCookie);
}}
