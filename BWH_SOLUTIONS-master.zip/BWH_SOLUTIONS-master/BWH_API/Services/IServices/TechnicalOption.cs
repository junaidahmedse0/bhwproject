using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface ITechnicalOptionService
{
Task<List<TechnicalOptionDTO>> GetAllTechnicalOptionAsync(string authCookie);
Task<int> CreateTechnicalOptionAsync(TechnicalOptionDTO technicaloptionDTO, string authCookie);
Task UpdateTechnicalOptionAsync(TechnicalOptionDTO technicaloptionDTO, string authCookie);
 Task DeleteTechnicalOptionAsync(TechnicalOptionDTO technicaloptionDTO, string authCookie);
}}
