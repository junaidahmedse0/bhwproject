﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;


namespace BWH_API.Service.IService
{
    interface IHttpClientService
    {
        //DELETE Verb
        Task<HttpResponseMessage> SendDeleteAsync(string authCookie, string UriSuffix);

        Task<HttpResponseMessage> SendDeleteAsync(string authCookie, string UriSuffix, string _JsonPayload);

        Task<HttpResponseMessage> SendDeleteObjAsync(string authCookie, string UriSuffix, object Payload);


        //PUT Verb
        Task<HttpResponseMessage> SendPutAsync(string authCookie, string UriSuffix);

        Task<HttpResponseMessage> SendPutAsync(string authCookie, string UriSuffix, string _JsonPayload);

        Task<HttpResponseMessage> SendPutObjAsync(string authCookie, string UriSuffix, object Payload);

        //POST Verb
        Task<HttpResponseMessage> SendPostAsync(string authCookie, string UriSuffix);

        Task<HttpResponseMessage> SendPostAsync(string authCookie, string UriSuffix, string _JsonPayload);

        //Task<HttpResponseMessage> SendPostObjAsync(string authCookie, string UriSuffix, object Payload);


        //GET Verb
        Task<HttpResponseMessage> SendGetAsync(string authCookie, string UriSuffix);
    }
}