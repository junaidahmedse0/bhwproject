using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IGenderGroupService
{
Task<List<GenderGroupDTO>> GetAllGenderGroupAsync(string authCookie);
Task<int> CreateGenderGroupAsync(GenderGroupDTO gendergroupDTO, string authCookie);
Task UpdateGenderGroupAsync(GenderGroupDTO gendergroupDTO, string authCookie);
 Task DeleteGenderGroupAsync(GenderGroupDTO gendergroupDTO, string authCookie);
}}
