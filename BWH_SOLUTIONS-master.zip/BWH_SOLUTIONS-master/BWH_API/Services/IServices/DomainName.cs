using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IDomainNameService
{
Task<List<DomainNameDTO>> GetAllDomainNameAsync(string authCookie);
Task<int> CreateDomainNameAsync(DomainNameDTO domainnameDTO, string authCookie);
Task UpdateDomainNameAsync(DomainNameDTO domainnameDTO, string authCookie);
 Task DeleteDomainNameAsync(DomainNameDTO domainnameDTO, string authCookie);
}}
