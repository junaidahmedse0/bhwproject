using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IAmazonFeeDailyTrendsService
{
Task<List<AmazonFeeDailyTrendsDTO>> GetAllAmazonFeeDailyTrendsAsync(string authCookie);
Task<int> CreateAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonfeedailytrendsDTO, string authCookie);
Task UpdateAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonfeedailytrendsDTO, string authCookie);
 Task DeleteAmazonFeeDailyTrendsAsync(AmazonFeeDailyTrendsDTO amazonfeedailytrendsDTO, string authCookie);
}}
