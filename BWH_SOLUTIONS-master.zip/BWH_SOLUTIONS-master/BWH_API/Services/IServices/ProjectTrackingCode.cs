using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IProjectTrackingCodeService
{
Task<List<ProjectTrackingCodeDTO>> GetAllProjectTrackingCodeAsync(string authCookie);
Task<int> CreateProjectTrackingCodeAsync(ProjectTrackingCodeDTO projecttrackingcodeDTO, string authCookie);
Task UpdateProjectTrackingCodeAsync(ProjectTrackingCodeDTO projecttrackingcodeDTO, string authCookie);
 Task DeleteProjectTrackingCodeAsync(ProjectTrackingCodeDTO projecttrackingcodeDTO, string authCookie);
}}
