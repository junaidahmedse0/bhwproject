using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface IAgeGroupService
{
Task<List<AgeGroupDTO>> GetAllAgeGroupAsync(string authCookie);
Task<int> CreateAgeGroupAsync(AgeGroupDTO agegroupDTO, string authCookie);
Task UpdateAgeGroupAsync(AgeGroupDTO agegroupDTO, string authCookie);
 Task DeleteAgeGroupAsync(AgeGroupDTO agegroupDTO, string authCookie);
}}
