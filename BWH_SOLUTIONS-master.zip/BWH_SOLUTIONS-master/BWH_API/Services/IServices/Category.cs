using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public interface ICategoryService
{
Task<List<CategoryDTO>> GetAllCategoryAsync(string authCookie);
Task<int> CreateCategoryAsync(CategoryDTO categoryDTO, string authCookie);
Task UpdateCategoryAsync(CategoryDTO categoryDTO, string authCookie);
 Task DeleteCategoryAsync(CategoryDTO categoryDTO, string authCookie);
}}
