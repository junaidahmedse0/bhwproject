﻿using System;
using System.Threading.Tasks;
using BWH_API.Enums;
using static BWH_API.Enums.Enums;

namespace BWH_API.Service.IService
{
    interface ILogService
    {
        Task AddLogAsync<T>(string authCookie, BWH_API.Enums.Enums.LogLevel? logLevel = BWH_API.Enums.Enums.LogLevel.Info
              , string message = ""
              , string stackTrace = ""
              , string methodName = ""
              , DateTime? timestamp = null
              , long? userId = null);

        Task AddLogAsync<T>(string authCookie
            , BWH_API.Enums.Enums.LogLevel? logLevel = BWH_API.Enums.Enums.LogLevel.Info
            , Exception exception = null
            , string methodName = ""
            , DateTime? timestamp = null
            , long? userId = null);


        Task AddAuditAsync<T>(string authCookie, string action);

        Task AddAuditAsync(string authCookie, string controllerName, string action);

    }
}