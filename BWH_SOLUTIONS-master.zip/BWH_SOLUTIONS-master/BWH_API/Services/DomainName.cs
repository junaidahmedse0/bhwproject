using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class DomainNameService : IDomainNameService
{
private IDomainNameRepository _domainNameRepository { get; }
 public DomainNameService()
{
_domainNameRepository = new DomainNameRepository();
}
async public Task<List<DomainNameDTO>> GetAllDomainNameAsync(string authCookie)
{
try
{
return await _domainNameRepository.GetAllDomainNameAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateDomainNameAsync(DomainNameDTO domainNameDTO, string authCookie)
{
try
{
int insertId = await _domainNameRepository.CreateDomainNameAsync(domainNameDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateDomainNameAsync(DomainNameDTO domainNameDTO, string authCookie)
{
try
{
await _domainNameRepository.UpdateDomainNameAsync(domainNameDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteDomainNameAsync(DomainNameDTO domainNameDTO, string authCookie)
{
try
{
await _domainNameRepository.DeleteDomainNameAsync(domainNameDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
