using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class CountryService : ICountryService
{
private ICountryRepository _countryRepository { get; }
 public CountryService()
{
_countryRepository = new CountryRepository();
}
async public Task<List<CountryDTO>> GetAllCountryAsync(string authCookie)
{
try
{
return await _countryRepository.GetAllCountryAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateCountryAsync(CountryDTO countryDTO, string authCookie)
{
try
{
int insertId = await _countryRepository.CreateCountryAsync(countryDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateCountryAsync(CountryDTO countryDTO, string authCookie)
{
try
{
await _countryRepository.UpdateCountryAsync(countryDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteCountryAsync(CountryDTO countryDTO, string authCookie)
{
try
{
await _countryRepository.DeleteCountryAsync(countryDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
