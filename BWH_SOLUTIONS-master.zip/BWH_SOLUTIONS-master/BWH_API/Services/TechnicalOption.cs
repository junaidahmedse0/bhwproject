using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class TechnicalOptionService : ITechnicalOptionService
{
private ITechnicalOptionRepository _technicalOptionRepository { get; }
 public TechnicalOptionService()
{
_technicalOptionRepository = new TechnicalOptionRepository();
}
async public Task<List<TechnicalOptionDTO>> GetAllTechnicalOptionAsync(string authCookie)
{
try
{
return await _technicalOptionRepository.GetAllTechnicalOptionAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateTechnicalOptionAsync(TechnicalOptionDTO technicalOptionDTO, string authCookie)
{
try
{
int insertId = await _technicalOptionRepository.CreateTechnicalOptionAsync(technicalOptionDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateTechnicalOptionAsync(TechnicalOptionDTO technicalOptionDTO, string authCookie)
{
try
{
await _technicalOptionRepository.UpdateTechnicalOptionAsync(technicalOptionDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteTechnicalOptionAsync(TechnicalOptionDTO technicalOptionDTO, string authCookie)
{
try
{
await _technicalOptionRepository.DeleteTechnicalOptionAsync(technicalOptionDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
