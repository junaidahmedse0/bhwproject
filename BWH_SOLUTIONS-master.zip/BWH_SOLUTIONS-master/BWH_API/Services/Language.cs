using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class LanguageService : ILanguageService
{
private ILanguageRepository _languageRepository { get; }
 public LanguageService()
{
_languageRepository = new LanguageRepository();
}
async public Task<List<LanguageDTO>> GetAllLanguageAsync(string authCookie)
{
try
{
return await _languageRepository.GetAllLanguageAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateLanguageAsync(LanguageDTO languageDTO, string authCookie)
{
try
{
int insertId = await _languageRepository.CreateLanguageAsync(languageDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateLanguageAsync(LanguageDTO languageDTO, string authCookie)
{
try
{
await _languageRepository.UpdateLanguageAsync(languageDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteLanguageAsync(LanguageDTO languageDTO, string authCookie)
{
try
{
await _languageRepository.DeleteLanguageAsync(languageDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
