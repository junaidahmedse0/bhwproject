﻿using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;

namespace BWH_API.Services
{
    public class AccountService : IAccountService
    {
        public IAccountRepository _accountRepostory { get; set; }
        public AccountService( )
        { 
           _accountRepostory=new AccountRepository();
        }
        async public Task<object> Login(AuthenticationDto authentication)
        {
            try
            {
                var user = await _accountRepostory.Login(authentication);
                return user;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
        async public Task<int> Register(AuthenticationDto authentication)
        { 
            try
            {
                 int id = await _accountRepostory.Register(authentication);
                 return id;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
