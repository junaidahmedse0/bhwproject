using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class PeriodicityService : IPeriodicityService
{
private IPeriodicityRepository _periodicityRepository { get; }
 public PeriodicityService()
{
_periodicityRepository = new PeriodicityRepository();
}
async public Task<List<PeriodicityDTO>> GetAllPeriodicityAsync(string authCookie)
{
try
{
return await _periodicityRepository.GetAllPeriodicityAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreatePeriodicityAsync(PeriodicityDTO periodicityDTO, string authCookie)
{
try
{
int insertId = await _periodicityRepository.CreatePeriodicityAsync(periodicityDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdatePeriodicityAsync(PeriodicityDTO periodicityDTO, string authCookie)
{
try
{
await _periodicityRepository.UpdatePeriodicityAsync(periodicityDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeletePeriodicityAsync(PeriodicityDTO periodicityDTO, string authCookie)
{
try
{
await _periodicityRepository.DeletePeriodicityAsync(periodicityDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
