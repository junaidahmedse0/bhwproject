﻿using Newtonsoft.Json;
using BWH_API;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using BWH_API.Utility;

namespace BWH_API.Service
{
    public class HttpClientService : IHttpClientService
    {
        private const string CONTENT_TYPE = "application/json";

        private async Task<HttpResponseMessage> SendGenericAsync(string authCookie, string UriSuffix, string JsonPayload = "", HttpMethod methodType = null)
        {
            HttpResponseMessage result = null;

            try
            {
                using (var _httpClient = new HttpClient(new HttpClientHandler() { UseCookies = false }))
                {
                    _httpClient.Timeout = TimeSpan.FromSeconds(5); //Local API call, reduce timeout as we have to make each call with '.Result' return, which blocks the thread, i.e. await is not thread safe.
                    HttpRequestMessage req = new HttpRequestMessage(
                        methodType == null ? HttpMethod.Get : methodType
                        , Constants.BASE_URI + UriSuffix);

                    if (!String.IsNullOrEmpty(JsonPayload))
                    {
                        req.Content = new StringContent(JsonPayload
                        , Encoding.UTF8
                        , CONTENT_TYPE);
                    }


                    //Forward user auth cookie per each API call
                    if (!string.IsNullOrEmpty(authCookie))
                    {
                        bool isCookieAdded = req.Headers.TryAddWithoutValidation("Cookie", authCookie);
                    }


                    //NB: Nested try/catch required as the app DLL will loaded as external DLL in DesignerWeb project, exception originating from SendAsync of httpClient will not be cought by using only one try/catch
                    try
                    {
                        //NB: Don't use await, use .Result instead
                        result = _httpClient.SendAsync(req).Result;
                    }
                    catch (Exception ex)
                    {
                        DebugLogger.LogDebugInfo($"Exception while sending API Message : {ex.Message} StackTrace : {ex.StackTrace}");
                        result = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                        result.Content = new StringContent("api request failed.");
                    }
                }

                StringBuilder logContent = new StringBuilder();
                logContent.AppendLine($"URL - '{Constants.BASE_URI + UriSuffix}'");
                logContent.AppendLine($" | authCookieValue : '{authCookie}'");
                logContent.AppendLine($" | RequestPayload : {JsonPayload}");
                if (result != null)
                {
                    logContent.AppendLine($" | Response : {result.Content.ReadAsStringAsync().Result}");
                    logContent.AppendLine($" | ResponseStatusCode : {result.StatusCode}");
                }
                else
                {
                    logContent.AppendLine($" | NULL Result");
                }
                DebugLogger.LogDebugInfo(logContent.ToString());
            }
            catch (Exception ex) //Handle exception from the task run
            {
                StringBuilder logContent = new StringBuilder();
                logContent.AppendLine($"URL - '{Constants.BASE_URI + UriSuffix}'");
                logContent.AppendLine($" | Message : '{ex.Message}'");
                logContent.AppendLine($" | stackTrace : {ex.StackTrace}");
                logContent.AppendLine($" | authCookieValue : '{authCookie}'");
                logContent.AppendLine($" | RequestPayload : {JsonPayload}");
                DebugLogger.LogDebugInfo($"Error while executing httpClient {logContent}");

                result = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                result.Content = new StringContent(JsonConvert.SerializeObject(
                        new
                        {
                            Message = ex.Message,
                            StackTrace = ex.StackTrace
                        }
                    ));
            }

            return result;

        }


        #region Delete options

        public async Task<HttpResponseMessage> SendDeleteAsync(string authCookie, string UriSuffix)
        {
            return await SendGenericAsync(authCookie, UriSuffix, methodType: HttpMethod.Delete);
        }

        public async Task<HttpResponseMessage> SendDeleteAsync(string authCookie, string UriSuffix, string _JsonPayload)
        {
            return await SendGenericAsync(authCookie, UriSuffix, JsonPayload: _JsonPayload, methodType: HttpMethod.Delete);
        }

        public async Task<HttpResponseMessage> SendDeleteObjAsync(string authCookie, string UriSuffix, object Payload)
        {
            //Convert the obj to Json format
            string JsonPayload = JsonConvert.SerializeObject(Payload);

            return await this.SendDeleteAsync(authCookie, UriSuffix, JsonPayload);
        }

        #endregion Delete options



        #region Put options - update


        public async Task<HttpResponseMessage> SendPutAsync(string authCookie, string UriSuffix)
        {
            return await SendGenericAsync(authCookie, UriSuffix, methodType: HttpMethod.Put);
        }

        public async Task<HttpResponseMessage> SendPutAsync(string authCookie, string UriSuffix, string _JsonPayload)
        {
            return await this.SendGenericAsync(authCookie, UriSuffix, JsonPayload: _JsonPayload, methodType: HttpMethod.Put);
        }

        public async Task<HttpResponseMessage> SendPutObjAsync(string authCookie, string UriSuffix, object Payload)
        {

            //Convert the obj to Json format
            string JsonPayload = JsonConvert.SerializeObject(Payload);

            return await this.SendPutAsync(authCookie, UriSuffix, JsonPayload);
        }


        #endregion Put options - update



        #region Post options


        public async Task<HttpResponseMessage> SendPostAsync(string authCookie, string UriSuffix)
        {
            return await SendGenericAsync(authCookie, UriSuffix, methodType: HttpMethod.Post);
        }

        public async Task<HttpResponseMessage> SendPostAsync(string authCookie, string UriSuffix, string _JsonPayload)
        {
            return await this.SendGenericAsync(authCookie, UriSuffix, JsonPayload: _JsonPayload, methodType: HttpMethod.Post);
        }

        #endregion Post options



        #region Get options


        public async Task<HttpResponseMessage> SendGetAsync(string authCookie, string UriSuffix)
        {
            return await SendGenericAsync(authCookie, UriSuffix);
        }


        #endregion Get options

    }
}