using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class ExpertiseAreaService : IExpertiseAreaService
{
private IExpertiseAreaRepository _expertiseAreaRepository { get; }
 public ExpertiseAreaService()
{
_expertiseAreaRepository = new ExpertiseAreaRepository();
}
async public Task<List<ExpertiseAreaDTO>> GetAllExpertiseAreaAsync(string authCookie)
{
try
{
return await _expertiseAreaRepository.GetAllExpertiseAreaAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateExpertiseAreaAsync(ExpertiseAreaDTO expertiseAreaDTO, string authCookie)
{
try
{
int insertId = await _expertiseAreaRepository.CreateExpertiseAreaAsync(expertiseAreaDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateExpertiseAreaAsync(ExpertiseAreaDTO expertiseAreaDTO, string authCookie)
{
try
{
await _expertiseAreaRepository.UpdateExpertiseAreaAsync(expertiseAreaDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteExpertiseAreaAsync(ExpertiseAreaDTO expertiseAreaDTO, string authCookie)
{
try
{
await _expertiseAreaRepository.DeleteExpertiseAreaAsync(expertiseAreaDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
