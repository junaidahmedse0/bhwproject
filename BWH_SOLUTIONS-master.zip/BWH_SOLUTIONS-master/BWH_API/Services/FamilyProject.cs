using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class FamilyProjectService : IFamilyProjectService
{
private IFamilyProjectRepository _familyProjectRepository { get; }
 public FamilyProjectService()
{
_familyProjectRepository = new FamilyProjectRepository();
}
async public Task<List<FamilyProjectDTO>> GetAllFamilyProjectAsync(string authCookie)
{
try
{
return await _familyProjectRepository.GetAllFamilyProjectAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateFamilyProjectAsync(FamilyProjectDTO familyProjectDTO, string authCookie)
{
try
{
int insertId = await _familyProjectRepository.CreateFamilyProjectAsync(familyProjectDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateFamilyProjectAsync(FamilyProjectDTO familyProjectDTO, string authCookie)
{
try
{
await _familyProjectRepository.UpdateFamilyProjectAsync(familyProjectDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteFamilyProjectAsync(FamilyProjectDTO familyProjectDTO, string authCookie)
{
try
{
await _familyProjectRepository.DeleteFamilyProjectAsync(familyProjectDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
