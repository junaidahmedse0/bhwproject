using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Service.IService;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Service.IService
{
public class ProjectTrackingCodeService : IProjectTrackingCodeService
{
private IProjectTrackingCodeRepository _projectTrackingCodeRepository { get; }
 public ProjectTrackingCodeService()
{
_projectTrackingCodeRepository = new ProjectTrackingCodeRepository();
}
async public Task<List<ProjectTrackingCodeDTO>> GetAllProjectTrackingCodeAsync(string authCookie)
{
try
{
return await _projectTrackingCodeRepository.GetAllProjectTrackingCodeAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateProjectTrackingCodeAsync(ProjectTrackingCodeDTO projectTrackingCodeDTO, string authCookie)
{
try
{
int insertId = await _projectTrackingCodeRepository.CreateProjectTrackingCodeAsync(projectTrackingCodeDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateProjectTrackingCodeAsync(ProjectTrackingCodeDTO projectTrackingCodeDTO, string authCookie)
{
try
{
await _projectTrackingCodeRepository.UpdateProjectTrackingCodeAsync(projectTrackingCodeDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteProjectTrackingCodeAsync(ProjectTrackingCodeDTO projectTrackingCodeDTO, string authCookie)
{
try
{
await _projectTrackingCodeRepository.DeleteProjectTrackingCodeAsync(projectTrackingCodeDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
