using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class EntityTechnicalOptionService : IEntityTechnicalOptionService
{
private IEntityTechnicalOptionRepository _entityTechnicalOptionRepository { get; }
 public EntityTechnicalOptionService()
{
_entityTechnicalOptionRepository = new EntityTechnicalOptionRepository();
}
async public Task<List<EntityTechnicalOptionDTO>> GetAllEntityTechnicalOptionAsync(string authCookie)
{
try
{
return await _entityTechnicalOptionRepository.GetAllEntityTechnicalOptionAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entityTechnicalOptionDTO, string authCookie)
{
try
{
int insertId = await _entityTechnicalOptionRepository.CreateEntityTechnicalOptionAsync(entityTechnicalOptionDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entityTechnicalOptionDTO, string authCookie)
{
try
{
await _entityTechnicalOptionRepository.UpdateEntityTechnicalOptionAsync(entityTechnicalOptionDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteEntityTechnicalOptionAsync(EntityTechnicalOptionDTO entityTechnicalOptionDTO, string authCookie)
{
try
{
await _entityTechnicalOptionRepository.DeleteEntityTechnicalOptionAsync(entityTechnicalOptionDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
