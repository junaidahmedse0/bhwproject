using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class ThemeService : IThemeService
{
private IThemeRepository _themeRepository { get; }
 public ThemeService()
{
_themeRepository = new ThemeRepository();
}
async public Task<List<ThemeDTO>> GetAllThemeAsync(string authCookie)
{
try
{
return await _themeRepository.GetAllThemeAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateThemeAsync(ThemeDTO themeDTO, string authCookie)
{
try
{
int insertId = await _themeRepository.CreateThemeAsync(themeDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateThemeAsync(ThemeDTO themeDTO, string authCookie)
{
try
{
await _themeRepository.UpdateThemeAsync(themeDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteThemeAsync(ThemeDTO themeDTO, string authCookie)
{
try
{
await _themeRepository.DeleteThemeAsync(themeDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
