using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class TrackingCodeService : ITrackingCodeService
{
private ITrackingCodeRepository _trackingCodeRepository { get; }
 public TrackingCodeService()
{
_trackingCodeRepository = new TrackingCodeRepository();
}
async public Task<List<TrackingCodeDTO>> GetAllTrackingCodeAsync(string authCookie)
{
try
{
return await _trackingCodeRepository.GetAllTrackingCodeAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateTrackingCodeAsync(TrackingCodeDTO trackingCodeDTO, string authCookie)
{
try
{
int insertId = await _trackingCodeRepository.CreateTrackingCodeAsync(trackingCodeDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateTrackingCodeAsync(TrackingCodeDTO trackingCodeDTO, string authCookie)
{
try
{
await _trackingCodeRepository.UpdateTrackingCodeAsync(trackingCodeDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteTrackingCodeAsync(TrackingCodeDTO trackingCodeDTO, string authCookie)
{
try
{
await _trackingCodeRepository.DeleteTrackingCodeAsync(trackingCodeDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
