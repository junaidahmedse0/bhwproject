using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class EntityTypeService : IEntityTypeService
{
private IEntityTypeRepository _entityTypeRepository { get; }
 public EntityTypeService()
{
_entityTypeRepository = new EntityTypeRepository();
}
async public Task<List<EntityTypeDTO>> GetAllEntityTypeAsync(string authCookie)
{
try
{
return await _entityTypeRepository.GetAllEntityTypeAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateEntityTypeAsync(EntityTypeDTO entityTypeDTO, string authCookie)
{
try
{
int insertId = await _entityTypeRepository.CreateEntityTypeAsync(entityTypeDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateEntityTypeAsync(EntityTypeDTO entityTypeDTO, string authCookie)
{
try
{
await _entityTypeRepository.UpdateEntityTypeAsync(entityTypeDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteEntityTypeAsync(EntityTypeDTO entityTypeDTO, string authCookie)
{
try
{
await _entityTypeRepository.DeleteEntityTypeAsync(entityTypeDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
