using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class DateOptionService : IDateOptionService
{
private IDateOptionRepository _dateOptionRepository { get; }
 public DateOptionService()
{
_dateOptionRepository = new DateOptionRepository();
}
async public Task<List<DateOptionDTO>> GetAllDateOptionAsync(string authCookie)
{
try
{
return await _dateOptionRepository.GetAllDateOptionAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateDateOptionAsync(DateOptionDTO dateOptionDTO, string authCookie)
{
try
{
int insertId = await _dateOptionRepository.CreateDateOptionAsync(dateOptionDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateDateOptionAsync(DateOptionDTO dateOptionDTO, string authCookie)
{
try
{
await _dateOptionRepository.UpdateDateOptionAsync(dateOptionDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteDateOptionAsync(DateOptionDTO dateOptionDTO, string authCookie)
{
try
{
await _dateOptionRepository.DeleteDateOptionAsync(dateOptionDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
