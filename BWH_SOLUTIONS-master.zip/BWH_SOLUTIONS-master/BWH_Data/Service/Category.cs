using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class CategoryService : ICategoryService
{
private ICategoryRepository _categoryRepository { get; }
 public CategoryService()
{
_categoryRepository = new CategoryRepository();
}
async public Task<List<CategoryDTO>> GetAllCategoryAsync(string authCookie)
{
try
{
return await _categoryRepository.GetAllCategoryAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateCategoryAsync(CategoryDTO categoryDTO, string authCookie)
{
try
{
int insertId = await _categoryRepository.CreateCategoryAsync(categoryDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateCategoryAsync(CategoryDTO categoryDTO, string authCookie)
{
try
{
await _categoryRepository.UpdateCategoryAsync(categoryDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteCategoryAsync(CategoryDTO categoryDTO, string authCookie)
{
try
{
await _categoryRepository.DeleteCategoryAsync(categoryDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
