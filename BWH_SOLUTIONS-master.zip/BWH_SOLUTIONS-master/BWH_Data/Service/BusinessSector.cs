using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class BusinessSectorService : IBusinessSectorService
{
private IBusinessSectorRepository _businessSectorRepository { get; }
 public BusinessSectorService()
{
_businessSectorRepository = new BusinessSectorRepository();
}
async public Task<List<BusinessSectorDTO>> GetAllBusinessSectorAsync(string authCookie)
{
try
{
return await _businessSectorRepository.GetAllBusinessSectorAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateBusinessSectorAsync(BusinessSectorDTO businessSectorDTO, string authCookie)
{
try
{
int insertId = await _businessSectorRepository.CreateBusinessSectorAsync(businessSectorDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateBusinessSectorAsync(BusinessSectorDTO businessSectorDTO, string authCookie)
{
try
{
await _businessSectorRepository.UpdateBusinessSectorAsync(businessSectorDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteBusinessSectorAsync(BusinessSectorDTO businessSectorDTO, string authCookie)
{
try
{
await _businessSectorRepository.DeleteBusinessSectorAsync(businessSectorDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
