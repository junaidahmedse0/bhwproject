using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class HostService : IHostService
{
private IHostRepository _hostRepository { get; }
 public HostService()
{
_hostRepository = new HostRepository();
}
async public Task<List<HostDTO>> GetAllHostAsync(string authCookie)
{
try
{
return await _hostRepository.GetAllHostAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateHostAsync(HostDTO hostDTO, string authCookie)
{
try
{
int insertId = await _hostRepository.CreateHostAsync(hostDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateHostAsync(HostDTO hostDTO, string authCookie)
{
try
{
await _hostRepository.UpdateHostAsync(hostDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteHostAsync(HostDTO hostDTO, string authCookie)
{
try
{
await _hostRepository.DeleteHostAsync(hostDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
