using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IEntityDateOptionService
{
Task<List<EntityDateOptionDTO>> GetAllEntityDateOptionAsync(string authCookie);
Task<int> CreateEntityDateOptionAsync(EntityDateOptionDTO entitydateoptionDTO, string authCookie);
Task UpdateEntityDateOptionAsync(EntityDateOptionDTO entitydateoptionDTO, string authCookie);
 Task DeleteEntityDateOptionAsync(EntityDateOptionDTO entitydateoptionDTO, string authCookie);
}}
