using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IThemeService
{
Task<List<ThemeDTO>> GetAllThemeAsync(string authCookie);
Task<int> CreateThemeAsync(ThemeDTO themeDTO, string authCookie);
Task UpdateThemeAsync(ThemeDTO themeDTO, string authCookie);
 Task DeleteThemeAsync(ThemeDTO themeDTO, string authCookie);
}}
