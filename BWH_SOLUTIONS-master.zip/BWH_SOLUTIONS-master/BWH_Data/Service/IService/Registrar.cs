using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IRegistrarService
{
Task<List<RegistrarDTO>> GetAllRegistrarAsync(string authCookie);
Task<int> CreateRegistrarAsync(RegistrarDTO registrarDTO, string authCookie);
Task UpdateRegistrarAsync(RegistrarDTO registrarDTO, string authCookie);
 Task DeleteRegistrarAsync(RegistrarDTO registrarDTO, string authCookie);
}}
