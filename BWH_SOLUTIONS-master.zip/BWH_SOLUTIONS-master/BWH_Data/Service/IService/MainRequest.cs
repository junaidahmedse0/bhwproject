using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IMainRequestService
{
Task<List<MainRequestDTO>> GetAllMainRequestAsync(string authCookie);
Task<int> CreateMainRequestAsync(MainRequestDTO mainrequestDTO, string authCookie);
Task UpdateMainRequestAsync(MainRequestDTO mainrequestDTO, string authCookie);
 Task DeleteMainRequestAsync(MainRequestDTO mainrequestDTO, string authCookie);
}}
