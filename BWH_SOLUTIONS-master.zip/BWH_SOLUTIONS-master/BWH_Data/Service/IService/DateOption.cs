using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IDateOptionService
{
Task<List<DateOptionDTO>> GetAllDateOptionAsync(string authCookie);
Task<int> CreateDateOptionAsync(DateOptionDTO dateoptionDTO, string authCookie);
Task UpdateDateOptionAsync(DateOptionDTO dateoptionDTO, string authCookie);
 Task DeleteDateOptionAsync(DateOptionDTO dateoptionDTO, string authCookie);
}}
