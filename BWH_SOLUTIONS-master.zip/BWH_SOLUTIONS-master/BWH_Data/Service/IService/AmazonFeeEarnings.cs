using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IAmazonFeeEarningsService
{
Task<List<AmazonFeeEarningsDTO>> GetAllAmazonFeeEarningsAsync(string authCookie);
Task<int> CreateAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonfeeearningsDTO, string authCookie);
Task UpdateAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonfeeearningsDTO, string authCookie);
 Task DeleteAmazonFeeEarningsAsync(AmazonFeeEarningsDTO amazonfeeearningsDTO, string authCookie);
}}
