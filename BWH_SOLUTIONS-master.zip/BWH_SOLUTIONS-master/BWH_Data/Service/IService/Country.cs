using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface ICountryService
{
Task<List<CountryDTO>> GetAllCountryAsync(string authCookie);
Task<int> CreateCountryAsync(CountryDTO countryDTO, string authCookie);
Task UpdateCountryAsync(CountryDTO countryDTO, string authCookie);
 Task DeleteCountryAsync(CountryDTO countryDTO, string authCookie);
}}
