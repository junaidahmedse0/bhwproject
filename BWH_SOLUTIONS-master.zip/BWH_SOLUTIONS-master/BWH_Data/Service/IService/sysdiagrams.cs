using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IsysdiagramsService
{
Task<List<sysdiagramsDTO>> GetAllsysdiagramsAsync(string authCookie);
Task<int> CreatesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO, string authCookie);
Task UpdatesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO, string authCookie);
 Task DeletesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO, string authCookie);
}}
