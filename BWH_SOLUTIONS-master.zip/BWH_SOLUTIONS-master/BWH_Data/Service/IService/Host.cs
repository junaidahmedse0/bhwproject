using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IHostService
{
Task<List<HostDTO>> GetAllHostAsync(string authCookie);
Task<int> CreateHostAsync(HostDTO hostDTO, string authCookie);
Task UpdateHostAsync(HostDTO hostDTO, string authCookie);
 Task DeleteHostAsync(HostDTO hostDTO, string authCookie);
}}
