using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IAmazonFeeLinkTypeService
{
Task<List<AmazonFeeLinkTypeDTO>> GetAllAmazonFeeLinkTypeAsync(string authCookie);
Task<int> CreateAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonfeelinktypeDTO, string authCookie);
Task UpdateAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonfeelinktypeDTO, string authCookie);
 Task DeleteAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonfeelinktypeDTO, string authCookie);
}}
