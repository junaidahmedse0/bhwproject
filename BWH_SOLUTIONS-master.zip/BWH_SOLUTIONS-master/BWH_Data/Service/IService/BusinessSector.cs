using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IBusinessSectorService
{
Task<List<BusinessSectorDTO>> GetAllBusinessSectorAsync(string authCookie);
Task<int> CreateBusinessSectorAsync(BusinessSectorDTO businesssectorDTO, string authCookie);
Task UpdateBusinessSectorAsync(BusinessSectorDTO businesssectorDTO, string authCookie);
 Task DeleteBusinessSectorAsync(BusinessSectorDTO businesssectorDTO, string authCookie);
}}
