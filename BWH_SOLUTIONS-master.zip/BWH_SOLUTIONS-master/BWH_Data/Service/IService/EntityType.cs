using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IEntityTypeService
{
Task<List<EntityTypeDTO>> GetAllEntityTypeAsync(string authCookie);
Task<int> CreateEntityTypeAsync(EntityTypeDTO entitytypeDTO, string authCookie);
Task UpdateEntityTypeAsync(EntityTypeDTO entitytypeDTO, string authCookie);
 Task DeleteEntityTypeAsync(EntityTypeDTO entitytypeDTO, string authCookie);
}}
