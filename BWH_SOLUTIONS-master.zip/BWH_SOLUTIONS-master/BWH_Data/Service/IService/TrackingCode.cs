using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface ITrackingCodeService
{
Task<List<TrackingCodeDTO>> GetAllTrackingCodeAsync(string authCookie);
Task<int> CreateTrackingCodeAsync(TrackingCodeDTO trackingcodeDTO, string authCookie);
Task UpdateTrackingCodeAsync(TrackingCodeDTO trackingcodeDTO, string authCookie);
 Task DeleteTrackingCodeAsync(TrackingCodeDTO trackingcodeDTO, string authCookie);
}}
