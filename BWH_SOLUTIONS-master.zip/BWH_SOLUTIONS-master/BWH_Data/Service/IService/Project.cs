using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IProjectService
{
Task<List<ProjectDTO>> GetAllProjectAsync(string authCookie);
Task<int> CreateProjectAsync(ProjectDTO projectDTO, string authCookie);
Task UpdateProjectAsync(ProjectDTO projectDTO, string authCookie);
 Task DeleteProjectAsync(ProjectDTO projectDTO, string authCookie);
}}
