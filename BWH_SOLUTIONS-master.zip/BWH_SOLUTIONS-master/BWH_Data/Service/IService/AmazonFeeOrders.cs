using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IAmazonFeeOrdersService
{
Task<List<AmazonFeeOrdersDTO>> GetAllAmazonFeeOrdersAsync(string authCookie);
Task<int> CreateAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonfeeordersDTO, string authCookie);
Task UpdateAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonfeeordersDTO, string authCookie);
 Task DeleteAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonfeeordersDTO, string authCookie);
}}
