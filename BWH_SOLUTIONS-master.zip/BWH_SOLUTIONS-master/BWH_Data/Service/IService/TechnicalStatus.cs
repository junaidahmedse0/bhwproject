using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface ITechnicalStatusService
{
Task<List<TechnicalStatusDTO>> GetAllTechnicalStatusAsync(string authCookie);
Task<int> CreateTechnicalStatusAsync(TechnicalStatusDTO technicalstatusDTO, string authCookie);
Task UpdateTechnicalStatusAsync(TechnicalStatusDTO technicalstatusDTO, string authCookie);
 Task DeleteTechnicalStatusAsync(TechnicalStatusDTO technicalstatusDTO, string authCookie);
}}
