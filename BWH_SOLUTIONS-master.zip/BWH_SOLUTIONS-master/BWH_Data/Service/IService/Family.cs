using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IFamilyService
{
Task<List<FamilyDTO>> GetAllFamilyAsync(string authCookie);
Task<int> CreateFamilyAsync(FamilyDTO familyDTO, string authCookie);
Task UpdateFamilyAsync(FamilyDTO familyDTO, string authCookie);
 Task DeleteFamilyAsync(FamilyDTO familyDTO, string authCookie);
}}
