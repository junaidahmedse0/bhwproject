using BWH_API.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public interface IPeriodicityService
{
Task<List<PeriodicityDTO>> GetAllPeriodicityAsync(string authCookie);
Task<int> CreatePeriodicityAsync(PeriodicityDTO periodicityDTO, string authCookie);
Task UpdatePeriodicityAsync(PeriodicityDTO periodicityDTO, string authCookie);
 Task DeletePeriodicityAsync(PeriodicityDTO periodicityDTO, string authCookie);
}}
