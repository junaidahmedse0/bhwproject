using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class MainRequestService : IMainRequestService
{
private IMainRequestRepository _mainRequestRepository { get; }
 public MainRequestService()
{
_mainRequestRepository = new MainRequestRepository();
}
async public Task<List<MainRequestDTO>> GetAllMainRequestAsync(string authCookie)
{
try
{
return await _mainRequestRepository.GetAllMainRequestAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateMainRequestAsync(MainRequestDTO mainRequestDTO, string authCookie)
{
try
{
int insertId = await _mainRequestRepository.CreateMainRequestAsync(mainRequestDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateMainRequestAsync(MainRequestDTO mainRequestDTO, string authCookie)
{
try
{
await _mainRequestRepository.UpdateMainRequestAsync(mainRequestDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteMainRequestAsync(MainRequestDTO mainRequestDTO, string authCookie)
{
try
{
await _mainRequestRepository.DeleteMainRequestAsync(mainRequestDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
