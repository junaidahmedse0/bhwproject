using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class TechnicalStatusService : ITechnicalStatusService
{
private ITechnicalStatusRepository _technicalStatusRepository { get; }
 public TechnicalStatusService()
{
_technicalStatusRepository = new TechnicalStatusRepository();
}
async public Task<List<TechnicalStatusDTO>> GetAllTechnicalStatusAsync(string authCookie)
{
try
{
return await _technicalStatusRepository.GetAllTechnicalStatusAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateTechnicalStatusAsync(TechnicalStatusDTO technicalStatusDTO, string authCookie)
{
try
{
int insertId = await _technicalStatusRepository.CreateTechnicalStatusAsync(technicalStatusDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateTechnicalStatusAsync(TechnicalStatusDTO technicalStatusDTO, string authCookie)
{
try
{
await _technicalStatusRepository.UpdateTechnicalStatusAsync(technicalStatusDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteTechnicalStatusAsync(TechnicalStatusDTO technicalStatusDTO, string authCookie)
{
try
{
await _technicalStatusRepository.DeleteTechnicalStatusAsync(technicalStatusDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
