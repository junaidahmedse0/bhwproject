using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class sysdiagramsService : IsysdiagramsService
{
private IsysdiagramsRepository _sysdiagramsRepository { get; }
 public sysdiagramsService()
{
_sysdiagramsRepository = new sysdiagramsRepository();
}
async public Task<List<sysdiagramsDTO>> GetAllsysdiagramsAsync(string authCookie)
{
try
{
return await _sysdiagramsRepository.GetAllsysdiagramsAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreatesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO, string authCookie)
{
try
{
int insertId = await _sysdiagramsRepository.CreatesysdiagramsAsync(sysdiagramsDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdatesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO, string authCookie)
{
try
{
await _sysdiagramsRepository.UpdatesysdiagramsAsync(sysdiagramsDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeletesysdiagramsAsync(sysdiagramsDTO sysdiagramsDTO, string authCookie)
{
try
{
await _sysdiagramsRepository.DeletesysdiagramsAsync(sysdiagramsDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
