using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class AmazonFeeOrdersService : IAmazonFeeOrdersService
{
private IAmazonFeeOrdersRepository _amazonFeeOrdersRepository { get; }
 public AmazonFeeOrdersService()
{
_amazonFeeOrdersRepository = new AmazonFeeOrdersRepository();
}
async public Task<List<AmazonFeeOrdersDTO>> GetAllAmazonFeeOrdersAsync(string authCookie)
{
try
{
return await _amazonFeeOrdersRepository.GetAllAmazonFeeOrdersAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonFeeOrdersDTO, string authCookie)
{
try
{
int insertId = await _amazonFeeOrdersRepository.CreateAmazonFeeOrdersAsync(amazonFeeOrdersDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonFeeOrdersDTO, string authCookie)
{
try
{
await _amazonFeeOrdersRepository.UpdateAmazonFeeOrdersAsync(amazonFeeOrdersDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteAmazonFeeOrdersAsync(AmazonFeeOrdersDTO amazonFeeOrdersDTO, string authCookie)
{
try
{
await _amazonFeeOrdersRepository.DeleteAmazonFeeOrdersAsync(amazonFeeOrdersDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
