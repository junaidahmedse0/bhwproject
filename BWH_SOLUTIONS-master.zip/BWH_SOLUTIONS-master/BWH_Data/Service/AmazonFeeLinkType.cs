using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class AmazonFeeLinkTypeService : IAmazonFeeLinkTypeService
{
private IAmazonFeeLinkTypeRepository _amazonFeeLinkTypeRepository { get; }
 public AmazonFeeLinkTypeService()
{
_amazonFeeLinkTypeRepository = new AmazonFeeLinkTypeRepository();
}
async public Task<List<AmazonFeeLinkTypeDTO>> GetAllAmazonFeeLinkTypeAsync(string authCookie)
{
try
{
return await _amazonFeeLinkTypeRepository.GetAllAmazonFeeLinkTypeAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonFeeLinkTypeDTO, string authCookie)
{
try
{
int insertId = await _amazonFeeLinkTypeRepository.CreateAmazonFeeLinkTypeAsync(amazonFeeLinkTypeDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonFeeLinkTypeDTO, string authCookie)
{
try
{
await _amazonFeeLinkTypeRepository.UpdateAmazonFeeLinkTypeAsync(amazonFeeLinkTypeDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteAmazonFeeLinkTypeAsync(AmazonFeeLinkTypeDTO amazonFeeLinkTypeDTO, string authCookie)
{
try
{
await _amazonFeeLinkTypeRepository.DeleteAmazonFeeLinkTypeAsync(amazonFeeLinkTypeDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
