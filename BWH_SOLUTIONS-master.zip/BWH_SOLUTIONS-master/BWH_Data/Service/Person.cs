using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class PersonService : IPersonService
{
private IPersonRepository _personRepository { get; }
 public PersonService()
{
_personRepository = new PersonRepository();
}
async public Task<List<PersonDTO>> GetAllPersonAsync(string authCookie)
{
try
{
return await _personRepository.GetAllPersonAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreatePersonAsync(PersonDTO personDTO, string authCookie)
{
try
{
int insertId = await _personRepository.CreatePersonAsync(personDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdatePersonAsync(PersonDTO personDTO, string authCookie)
{
try
{
await _personRepository.UpdatePersonAsync(personDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeletePersonAsync(PersonDTO personDTO, string authCookie)
{
try
{
await _personRepository.DeletePersonAsync(personDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
