using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class EntityDateOptionService : IEntityDateOptionService
{
private IEntityDateOptionRepository _entityDateOptionRepository { get; }
 public EntityDateOptionService()
{
_entityDateOptionRepository = new EntityDateOptionRepository();
}
async public Task<List<EntityDateOptionDTO>> GetAllEntityDateOptionAsync(string authCookie)
{
try
{
return await _entityDateOptionRepository.GetAllEntityDateOptionAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateEntityDateOptionAsync(EntityDateOptionDTO entityDateOptionDTO, string authCookie)
{
try
{
int insertId = await _entityDateOptionRepository.CreateEntityDateOptionAsync(entityDateOptionDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateEntityDateOptionAsync(EntityDateOptionDTO entityDateOptionDTO, string authCookie)
{
try
{
await _entityDateOptionRepository.UpdateEntityDateOptionAsync(entityDateOptionDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteEntityDateOptionAsync(EntityDateOptionDTO entityDateOptionDTO, string authCookie)
{
try
{
await _entityDateOptionRepository.DeleteEntityDateOptionAsync(entityDateOptionDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
