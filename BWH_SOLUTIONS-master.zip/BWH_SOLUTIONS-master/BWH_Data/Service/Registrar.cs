using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class RegistrarService : IRegistrarService
{
private IRegistrarRepository _registrarRepository { get; }
 public RegistrarService()
{
_registrarRepository = new RegistrarRepository();
}
async public Task<List<RegistrarDTO>> GetAllRegistrarAsync(string authCookie)
{
try
{
return await _registrarRepository.GetAllRegistrarAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateRegistrarAsync(RegistrarDTO registrarDTO, string authCookie)
{
try
{
int insertId = await _registrarRepository.CreateRegistrarAsync(registrarDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateRegistrarAsync(RegistrarDTO registrarDTO, string authCookie)
{
try
{
await _registrarRepository.UpdateRegistrarAsync(registrarDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteRegistrarAsync(RegistrarDTO registrarDTO, string authCookie)
{
try
{
await _registrarRepository.DeleteRegistrarAsync(registrarDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
