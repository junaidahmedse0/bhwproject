using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class AgeGroupService : IAgeGroupService
{
private IAgeGroupRepository _ageGroupRepository { get; }
 public AgeGroupService()
{
_ageGroupRepository = new AgeGroupRepository();
}
async public Task<List<AgeGroupDTO>> GetAllAgeGroupAsync(string authCookie)
{
try
{
return await _ageGroupRepository.GetAllAgeGroupAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateAgeGroupAsync(AgeGroupDTO ageGroupDTO, string authCookie)
{
try
{
int insertId = await _ageGroupRepository.CreateAgeGroupAsync(ageGroupDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateAgeGroupAsync(AgeGroupDTO ageGroupDTO, string authCookie)
{
try
{
await _ageGroupRepository.UpdateAgeGroupAsync(ageGroupDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteAgeGroupAsync(AgeGroupDTO ageGroupDTO, string authCookie)
{
try
{
await _ageGroupRepository.DeleteAgeGroupAsync(ageGroupDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
