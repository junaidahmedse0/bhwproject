using BWH_API.DTO;
using BWH_API.Repository;
using BWH_API.Repository.IRepository;
using BWH_API.Services.IServices;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace BWH_API.Services.IServices
{
public class ProjectService : IProjectService
{
private IProjectRepository _projectRepository { get; }
 public ProjectService()
{
_projectRepository = new ProjectRepository();
}
async public Task<List<ProjectDTO>> GetAllProjectAsync(string authCookie)
{
try
{
return await _projectRepository.GetAllProjectAsync();
}
catch (Exception e)
{
throw e;
}
}
async public Task<int> CreateProjectAsync(ProjectDTO projectDTO, string authCookie)
{
try
{
int insertId = await _projectRepository.CreateProjectAsync(projectDTO);
return insertId;
}
catch (Exception e)
{
throw e;
}
}
async public Task UpdateProjectAsync(ProjectDTO projectDTO, string authCookie)
{
try
{
await _projectRepository.UpdateProjectAsync(projectDTO);
}
catch (Exception e)
{
throw e;
}
}
async public Task DeleteProjectAsync(ProjectDTO projectDTO, string authCookie)
{
try
{
await _projectRepository.DeleteProjectAsync(projectDTO);
}
catch (Exception e)
{
throw e;
}
}
}}
