﻿using DevExpress.Xpo;
using DevExpress.Xpo.DB;
using DevExpress.Xpo.Metadata;

namespace BWH_Data
{
    public class ConnectionHelper
    {
        public static IDataLayer appDataLayer;
        static readonly Type[] PersistentTypes = new Type[] {
            //typeof(Departement),
            //typeof(Fonction),
            //typeof(Instance),
            //typeof(NiveauFormation),
            //typeof(Region),
            //typeof(Role),
            //typeof(Slameur),
            //typeof(SlameurResponsabilite),
            //typeof(SlameurRole),
            //typeof(Structure),
            //typeof(Uge),
        };

        public static string ConnectionString
        {
            get
            {
                var cnx = MSSqlConnectionProvider.GetConnectionString("178.33.123.226", "BWH_API_User", "Tstr%20SFRq.ptg", "BWH");
                return cnx;
            }
        }

        public static void Connect(bool threadSafe = true)
        {
            //Avoid setting dataLayer for plugin app to the default XPO property NOT to conflict default dataLayer call used in main/host application (i.e. Suadeo Designer)
            //XpoDefault.DataLayer = CreateDataLayer(threadSafe);
            appDataLayer = CreateDataLayer(threadSafe);
        }

        static IDataLayer CreateDataLayer(bool threadSafe)
        {
            string connStr = XpoDefault.GetConnectionPoolString(ConnectionString);
            ReflectionDictionary dictionary = new ReflectionDictionary();
            dictionary.GetDataStoreSchema(PersistentTypes);   // Pass all of your persistent object types to this method.
            AutoCreateOption autoCreateOption = AutoCreateOption.SchemaAlreadyExists;  // Use AutoCreateOption.DatabaseAndSchema if the database or tables do not exist. Use AutoCreateOption.SchemaAlreadyExists if the database already exists.
            IDataStore provider = XpoDefault.GetConnectionProvider(connStr, autoCreateOption);
            return threadSafe ? (IDataLayer)new ThreadSafeDataLayer(dictionary, provider) : new SimpleDataLayer(dictionary, provider);
        }
        public static UnitOfWork CreateUnitOfWork()
        {
            if (appDataLayer == null)
                Connect();

            return new UnitOfWork(appDataLayer);
        }

    }
}