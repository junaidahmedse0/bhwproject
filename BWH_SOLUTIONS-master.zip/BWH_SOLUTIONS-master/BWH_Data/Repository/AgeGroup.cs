using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class AgeGroupRepository : IAgeGroupRepository
{
async public Task<List<AgeGroupDTO>> GetAllAgeGroupAsync()
{
var result = new List<AgeGroupDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<AgeGroup>()
.Select(_ => new AgeGroupDTO()
 {
AgeGroupId = _.AgeGroupId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.AgeGroupId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateAgeGroupAsync(AgeGroupDTO ageGroupDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
AgeGroup newRecord = new AgeGroup(uow);
newRecord.AgeGroupId = ageGroupDTO.AgeGroupId;
newRecord.Title = ageGroupDTO.Title;
newRecord.DateCreated = ageGroupDTO.DateCreated;
newRecord.DateUpdated = ageGroupDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.AgeGroupId;
}}
async public Task UpdateAgeGroupAsync(AgeGroupDTO AgeGroupDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<AgeGroup>().Where(_ => _.AgeGroupId == AgeGroupDTO.AgeGroupId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.AgeGroupId = AgeGroupDTO.AgeGroupId;
recordToUpdate.Title = AgeGroupDTO.Title;
recordToUpdate.DateCreated = AgeGroupDTO.DateCreated;
recordToUpdate.DateUpdated = AgeGroupDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteAgeGroupAsync(AgeGroupDTO ageGroupDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<AgeGroup>().Where(_ => _.AgeGroupId == ageGroupDTO.AgeGroupId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
