using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class PeriodicityRepository : IPeriodicityRepository
{
async public Task<List<PeriodicityDTO>> GetAllPeriodicityAsync()
{
var result = new List<PeriodicityDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Periodicity>()
.Select(_ => new PeriodicityDTO()
 {
PeriodicityId = _.PeriodicityId,
Title = _.Title,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.PeriodicityId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreatePeriodicityAsync(PeriodicityDTO periodicityDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
Periodicity newRecord = new Periodicity(uow);
newRecord.PeriodicityId = periodicityDTO.PeriodicityId;
newRecord.Title = periodicityDTO.Title;
newRecord.DateCreated = periodicityDTO.DateCreated;
newRecord.DateUpdated = periodicityDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.PeriodicityId;
}}
async public Task UpdatePeriodicityAsync(PeriodicityDTO PeriodicityDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Periodicity>().Where(_ => _.PeriodicityId == PeriodicityDTO.PeriodicityId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.PeriodicityId = PeriodicityDTO.PeriodicityId;
recordToUpdate.Title = PeriodicityDTO.Title;
recordToUpdate.DateCreated = PeriodicityDTO.DateCreated;
recordToUpdate.DateUpdated = PeriodicityDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeletePeriodicityAsync(PeriodicityDTO periodicityDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Periodicity>().Where(_ => _.PeriodicityId == periodicityDTO.PeriodicityId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
