using DevExpress.Xpo;
using BWH_API.DTO;
using BWH_API.Repository.IRepository;
using BWH_API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace BWH_API.Repository
{
public class ProjectRepository : IProjectRepository
{
async public Task<List<ProjectDTO>> GetAllProjectAsync()
{
var result = new List<ProjectDTO>();
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
result = await uow.Query<Project>()
.Select(_ => new ProjectDTO()
 {
ProjectId = _.ProjectId,
CategoryId = _.CategoryId,
BusinessSectorId = _.BusinessSectorId,
ThemeId = _.ThemeId,
TechnicalStatusId = _.TechnicalStatusId,
LanguageId = _.LanguageId,
AgeGroupId = _.AgeGroupId,
GenderGroupId = _.GenderGroupId,
HostId = _.HostId,
DomainNameId = _.DomainNameId,
Code = _.Code,
Title = _.Title,
Description = _.Description,
Folder = _.Folder,
DateCreated = _.DateCreated,
DateUpdated = _.DateUpdated
}).OrderBy(_ => _.ProjectId).Distinct().ToListAsync();
}
return result;
}
async public Task<int> CreateProjectAsync(ProjectDTO projectDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
Project newRecord = new Project(uow);
newRecord.ProjectId = projectDTO.ProjectId;
newRecord.CategoryId = projectDTO.CategoryId;
newRecord.BusinessSectorId = projectDTO.BusinessSectorId;
newRecord.ThemeId = projectDTO.ThemeId;
newRecord.TechnicalStatusId = projectDTO.TechnicalStatusId;
newRecord.LanguageId = projectDTO.LanguageId;
newRecord.AgeGroupId = projectDTO.AgeGroupId;
newRecord.GenderGroupId = projectDTO.GenderGroupId;
newRecord.HostId = projectDTO.HostId;
newRecord.DomainNameId = projectDTO.DomainNameId;
newRecord.Code = projectDTO.Code;
newRecord.Title = projectDTO.Title;
newRecord.Description = projectDTO.Description;
newRecord.Folder = projectDTO.Folder;
newRecord.DateCreated = projectDTO.DateCreated;
newRecord.DateUpdated = projectDTO.DateUpdated;
await uow.CommitChangesAsync();
return newRecord.ProjectId;
}}
async public Task UpdateProjectAsync(ProjectDTO ProjectDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var recordToUpdate = uow.Query<Project>().Where(_ => _.ProjectId == ProjectDTO.ProjectId).FirstOrDefault();
if (recordToUpdate != null)
{
recordToUpdate.ProjectId = ProjectDTO.ProjectId;
recordToUpdate.CategoryId = ProjectDTO.CategoryId;
recordToUpdate.BusinessSectorId = ProjectDTO.BusinessSectorId;
recordToUpdate.ThemeId = ProjectDTO.ThemeId;
recordToUpdate.TechnicalStatusId = ProjectDTO.TechnicalStatusId;
recordToUpdate.LanguageId = ProjectDTO.LanguageId;
recordToUpdate.AgeGroupId = ProjectDTO.AgeGroupId;
recordToUpdate.GenderGroupId = ProjectDTO.GenderGroupId;
recordToUpdate.HostId = ProjectDTO.HostId;
recordToUpdate.DomainNameId = ProjectDTO.DomainNameId;
recordToUpdate.Code = ProjectDTO.Code;
recordToUpdate.Title = ProjectDTO.Title;
recordToUpdate.Description = ProjectDTO.Description;
recordToUpdate.Folder = ProjectDTO.Folder;
recordToUpdate.DateCreated = ProjectDTO.DateCreated;
recordToUpdate.DateUpdated = ProjectDTO.DateUpdated;
await uow.CommitChangesAsync();
}}}
async public Task DeleteProjectAsync(ProjectDTO projectDTO)
{
using (var uow = ConnectionHelper.CreateUnitOfWork())
{
var deleteToUpdate = uow.Query<Project>().Where(_ => _.ProjectId == projectDTO.ProjectId).FirstOrDefault();
if (deleteToUpdate != null)
{
deleteToUpdate.Delete();
await uow.CommitChangesAsync();
}
}
}
}}
